"""
CRUD операции для работы с базой данных
Create, Read, Update, Delete
"""
from datetime import date, time
from typing import List, Optional
from sqlalchemy import select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from database.models import User, Business, Service, Employee, Booking


# ===== USER CRUD =====

async def get_user_by_telegram_id(session: AsyncSession, telegram_id: int) -> Optional[User]:
    """Получить пользователя по Telegram ID (без создания)"""
    result = await session.execute(
        select(User).where(User.telegram_id == telegram_id)
    )
    return result.scalar_one_or_none()


async def get_or_create_user(
    session: AsyncSession,
    telegram_id: int,
    username: Optional[str],
    full_name: str
) -> User:
    """Получить пользователя или создать нового"""
    result = await session.execute(
        select(User).where(User.telegram_id == telegram_id)
    )
    user = result.scalar_one_or_none()

    if not user:
        user = User(
            telegram_id=telegram_id,
            username=username,
            full_name=full_name
        )
        session.add(user)
        await session.commit()
        await session.refresh(user)

    return user


async def update_user_phone(session: AsyncSession, user_id: int, phone: str) -> User:
    """Обновить номер телефона пользователя"""
    result = await session.execute(
        select(User).where(User.id == user_id)
    )
    user = result.scalar_one()
    user.phone = phone
    await session.commit()
    await session.refresh(user)
    return user


# ===== BUSINESS CRUD =====

async def create_business(
    session: AsyncSession,
    owner_id: int,
    name: str,
    business_type: str,
    **kwargs
) -> Business:
    """Создать новый бизнес"""
    business = Business(
        owner_id=owner_id,
        name=name,
        business_type=business_type,
        **kwargs
    )
    session.add(business)
    await session.commit()
    await session.refresh(business)
    return business


async def get_user_businesses(session: AsyncSession, user_id: int) -> List[Business]:
    """Получить все бизнесы пользователя"""
    result = await session.execute(
        select(Business).where(Business.owner_id == user_id)
    )
    return list(result.scalars().all())


async def get_all_active_businesses(session: AsyncSession) -> List[Business]:
    """Получить все активные бизнесы"""
    result = await session.execute(
        select(Business).where(Business.is_active == True)
    )
    return list(result.scalars().all())


async def get_business_by_id(session: AsyncSession, business_id: int) -> Optional[Business]:
    """Получить бизнес по ID"""
    result = await session.execute(
        select(Business).where(Business.id == business_id)
    )
    return result.scalar_one_or_none()


async def is_business_owner(session: AsyncSession, business_id: int, user_id: int) -> bool:
    """Проверить, является ли пользователь владельцем бизнеса"""
    result = await session.execute(
        select(Business).where(
            and_(Business.id == business_id, Business.owner_id == user_id)
        )
    )
    return result.scalar_one_or_none() is not None


# ===== SERVICE CRUD =====

async def create_service(
    session: AsyncSession,
    business_id: int,
    name: str,
    duration_minutes: int,
    **kwargs
) -> Service:
    """Создать услугу"""
    service = Service(
        business_id=business_id,
        name=name,
        duration_minutes=duration_minutes,
        **kwargs
    )
    session.add(service)
    await session.commit()
    await session.refresh(service)
    return service


async def get_business_services(session: AsyncSession, business_id: int) -> List[Service]:
    """Получить все услуги бизнеса"""
    result = await session.execute(
        select(Service).where(
            and_(Service.business_id == business_id, Service.is_active == True)
        )
    )
    return list(result.scalars().all())


async def get_service_by_id(session: AsyncSession, service_id: int) -> Optional[Service]:
    """Получить услугу по ID"""
    result = await session.execute(
        select(Service).where(Service.id == service_id)
    )
    return result.scalar_one_or_none()


# ===== EMPLOYEE CRUD =====

async def create_employee(
    session: AsyncSession,
    business_id: int,
    name: str,
    **kwargs
) -> Employee:
    """Создать сотрудника"""
    employee = Employee(
        business_id=business_id,
        name=name,
        **kwargs
    )
    session.add(employee)
    await session.commit()
    await session.refresh(employee)
    return employee


async def get_business_employees(session: AsyncSession, business_id: int) -> List[Employee]:
    """Получить всех сотрудников бизнеса"""
    result = await session.execute(
        select(Employee).where(
            and_(Employee.business_id == business_id, Employee.is_active == True)
        )
    )
    return list(result.scalars().all())


# ===== BOOKING CRUD =====

async def create_booking(
    session: AsyncSession,
    business_id: int,
    client_id: int,
    service_id: int,
    booking_date: date,
    booking_time: time,
    employee_id: Optional[int] = None,
    status: str = "confirmed",  # По умолчанию записи автоматически подтверждаются
    **kwargs
) -> Booking:
    """Создать запись"""
    # Проверка на двойное бронирование у мастера
    if employee_id:
        # Проверяем, не занят ли мастер в это время
        conflict_check = await session.execute(
            select(Booking).where(
                and_(
                    Booking.employee_id == employee_id,
                    Booking.booking_date == booking_date,
                    Booking.booking_time == booking_time,
                    Booking.status.in_(['pending', 'confirmed'])
                )
            )
        )
        existing_booking = conflict_check.scalar_one_or_none()
        if existing_booking:
            raise ValueError(f"Время {booking_time.strftime('%H:%M')} уже занято")

    # Проверка на дублирование записи одним клиентом (защита от двойного клика)
    client_duplicate_check = await session.execute(
        select(Booking).where(
            and_(
                Booking.client_id == client_id,
                Booking.business_id == business_id,
                Booking.service_id == service_id,
                Booking.booking_date == booking_date,
                Booking.booking_time == booking_time,
                Booking.status.in_(['pending', 'confirmed'])
            )
        )
    )
    duplicate_booking = client_duplicate_check.scalar_one_or_none()
    if duplicate_booking:
        # Возвращаем существующую запись вместо создания новой
        return duplicate_booking

    booking = Booking(
        business_id=business_id,
        client_id=client_id,
        service_id=service_id,
        employee_id=employee_id,
        booking_date=booking_date,
        booking_time=booking_time,
        status=status,
        **kwargs
    )
    session.add(booking)

    try:
        await session.commit()
        await session.refresh(booking)
        return booking
    except Exception as e:
        await session.rollback()
        # Если произошла ошибка при commit (например, race condition с дублированием)
        # Проверяем еще раз на конфликт и выдаем понятное сообщение
        if "unique" in str(e).lower() or "duplicate" in str(e).lower():
            raise ValueError(f"Время {booking_time.strftime('%H:%M')} уже занято другим клиентом")
        raise


async def get_user_bookings(session: AsyncSession, user_id: int) -> List[Booking]:
    """Получить все записи пользователя"""
    result = await session.execute(
        select(Booking)
        .where(Booking.client_id == user_id)
        .options(
            selectinload(Booking.business).selectinload(Business.owner),
            selectinload(Booking.service),
            selectinload(Booking.employee),
            selectinload(Booking.client)
        )
        .order_by(Booking.booking_date.desc(), Booking.booking_time.desc())
    )
    return list(result.scalars().all())


async def get_business_bookings(
    session: AsyncSession,
    business_id: int,
    booking_date: Optional[date] = None
) -> List[Booking]:
    """Получить записи бизнеса за определенную дату или все"""
    query = select(Booking).where(Booking.business_id == business_id)

    if booking_date:
        query = query.where(Booking.booking_date == booking_date)

    query = query.options(
        selectinload(Booking.client),
        selectinload(Booking.service),
        selectinload(Booking.employee)
    ).order_by(Booking.booking_date, Booking.booking_time)

    result = await session.execute(query)
    return list(result.scalars().all())


async def update_booking_status(
    session: AsyncSession,
    booking_id: int,
    status: str
) -> Booking:
    """Обновить статус записи"""
    result = await session.execute(
        select(Booking).where(Booking.id == booking_id)
    )
    booking = result.scalar_one()
    booking.status = status
    await session.commit()
    await session.refresh(booking)
    return booking


async def get_pending_reminders(session: AsyncSession) -> List[Booking]:
    """Получить записи, для которых нужно отправить напоминание"""
    # Записи на завтра, для которых еще не отправлялось напоминание
    result = await session.execute(
        select(Booking)
        .where(
            and_(
                Booking.status == "pending",
                Booking.reminder_sent == False
            )
        )
        .options(
            selectinload(Booking.client),
            selectinload(Booking.business),
            selectinload(Booking.service)
        )
    )
    return list(result.scalars().all())


async def mark_reminder_sent(session: AsyncSession, booking_id: int):
    """Отметить, что напоминание отправлено"""
    result = await session.execute(
        select(Booking).where(Booking.id == booking_id)
    )
    booking = result.scalar_one()
    booking.reminder_sent = True
    await session.commit()


async def get_employee_by_id(session: AsyncSession, employee_id: int) -> Optional[Employee]:
    """Получить сотрудника по ID"""
    result = await session.execute(
        select(Employee).where(Employee.id == employee_id)
    )
    return result.scalar_one_or_none()


async def delete_service(session: AsyncSession, service_id: int):
    """Удалить услугу"""
    result = await session.execute(
        select(Service).where(Service.id == service_id)
    )
    service = result.scalar_one()
    session.delete(service)
    await session.commit()


async def delete_employee(session: AsyncSession, employee_id: int):
    """Удалить сотрудника"""
    result = await session.execute(
        select(Employee).where(Employee.id == employee_id)
    )
    employee = result.scalar_one()
    session.delete(employee)
    await session.commit()


# ===== MASTER FUNCTIONS =====

async def get_employee_by_telegram_id(session: AsyncSession, telegram_id: int) -> Optional[Employee]:
    """Получить сотрудника по Telegram ID"""
    result = await session.execute(
        select(Employee)
        .options(selectinload(Employee.business))
        .where(Employee.telegram_id == telegram_id)
    )
    return result.scalar_one_or_none()


async def get_master_bookings(
    session: AsyncSession,
    employee_id: int,
    start_date: date,
    end_date: date
) -> List[Booking]:
    """Получить записи мастера за период"""
    result = await session.execute(
        select(Booking)
        .options(
            selectinload(Booking.client),
            selectinload(Booking.service),
            selectinload(Booking.business)
        )
        .where(Booking.employee_id == employee_id)
        .where(Booking.booking_date >= start_date)
        .where(Booking.booking_date <= end_date)
        .where(Booking.status.in_(["pending", "confirmed", "completed"]))
        .order_by(Booking.booking_date, Booking.booking_time)
    )
    return list(result.scalars().all())
