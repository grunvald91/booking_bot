"""
Модели базы данных для системы записи
"""
from datetime import datetime
from typing import List, Optional
from sqlalchemy import BigInteger, String, DateTime, ForeignKey, Boolean, Integer, Text, Time, Date
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    """Базовый класс для всех моделей"""
    pass


class User(Base):
    """Пользователи бота (клиенты и владельцы бизнеса)"""
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    username: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    full_name: Mapped[str] = mapped_column(String(255))
    phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Связь с бизнесами (если пользователь - владелец)
    businesses: Mapped[List["Business"]] = relationship(back_populates="owner", cascade="all, delete-orphan")
    # Связь с записями
    bookings: Mapped[List["Booking"]] = relationship(back_populates="client", cascade="all, delete-orphan")


class Business(Base):
    """Бизнесы (салон красоты, автосервис и т.д.)"""
    __tablename__ = "businesses"

    id: Mapped[int] = mapped_column(primary_key=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(String(255))
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    business_type: Mapped[str] = mapped_column(String(100))  # salon, auto_service, psychologist и т.д.
    address: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    working_hours_start: Mapped[Optional[datetime.time]] = mapped_column(Time, nullable=True)
    working_hours_end: Mapped[Optional[datetime.time]] = mapped_column(Time, nullable=True)
    break_start: Mapped[Optional[datetime.time]] = mapped_column(Time, nullable=True)  # Начало перерыва
    break_end: Mapped[Optional[datetime.time]] = mapped_column(Time, nullable=True)  # Конец перерыва
    booking_interval_minutes: Mapped[int] = mapped_column(Integer, default=30)  # Шаг записи по умолчанию
    photos: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # JSON массив file_id фотографий
    directions: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # Как добраться
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Связи
    owner: Mapped["User"] = relationship(back_populates="businesses")
    services: Mapped[List["Service"]] = relationship(back_populates="business", cascade="all, delete-orphan")
    employees: Mapped[List["Employee"]] = relationship(back_populates="business", cascade="all, delete-orphan")
    bookings: Mapped[List["Booking"]] = relationship(back_populates="business", cascade="all, delete-orphan")


class Service(Base):
    """Услуги бизнеса"""
    __tablename__ = "services"

    id: Mapped[int] = mapped_column(primary_key=True)
    business_id: Mapped[int] = mapped_column(ForeignKey("businesses.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(String(255))
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    duration_minutes: Mapped[int] = mapped_column(Integer)  # Длительность в минутах
    price: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)  # Цена (можно в копейках)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    # Связи
    business: Mapped["Business"] = relationship(back_populates="services")
    bookings: Mapped[List["Booking"]] = relationship(back_populates="service", cascade="all, delete-orphan")


class Employee(Base):
    """Сотрудники (мастера, механики, специалисты)"""
    __tablename__ = "employees"

    id: Mapped[int] = mapped_column(primary_key=True)
    business_id: Mapped[int] = mapped_column(ForeignKey("businesses.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(String(255))
    specialization: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    telegram_id: Mapped[Optional[int]] = mapped_column(BigInteger, nullable=True, unique=True)
    booking_interval_minutes: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)  # Индивидуальный шаг записи
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    # Связи
    business: Mapped["Business"] = relationship(back_populates="employees")
    bookings: Mapped[List["Booking"]] = relationship(back_populates="employee", cascade="all, delete-orphan")


class Booking(Base):
    """Записи клиентов"""
    __tablename__ = "bookings"

    id: Mapped[int] = mapped_column(primary_key=True)
    business_id: Mapped[int] = mapped_column(ForeignKey("businesses.id", ondelete="CASCADE"))
    client_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    service_id: Mapped[int] = mapped_column(ForeignKey("services.id", ondelete="CASCADE"))
    employee_id: Mapped[Optional[int]] = mapped_column(ForeignKey("employees.id", ondelete="SET NULL"), nullable=True)

    booking_date: Mapped[datetime.date] = mapped_column(Date)
    booking_time: Mapped[datetime.time] = mapped_column(Time)

    status: Mapped[str] = mapped_column(String(50), default="pending")  # pending, confirmed, cancelled, completed
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    reminder_sent: Mapped[bool] = mapped_column(Boolean, default=False)  # Deprecated, используем reminder_24h/2h
    reminder_24h_sent: Mapped[bool] = mapped_column(Boolean, default=False)  # Отправлено напоминание за 24ч
    reminder_2h_sent: Mapped[bool] = mapped_column(Boolean, default=False)  # Отправлено напоминание за 2ч
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Связи
    business: Mapped["Business"] = relationship(back_populates="bookings")
    client: Mapped["User"] = relationship(back_populates="bookings")
    service: Mapped["Service"] = relationship(back_populates="bookings")
    employee: Mapped["Employee"] = relationship(back_populates="bookings")
