"""
Подключение к базе данных и создание сессий
"""
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.pool import NullPool

from bot.config import DATABASE_URL
from database.models import Base


# Создаем асинхронный движок
engine = create_async_engine(
    DATABASE_URL,
    echo=False,  # Установите в True для отладки SQL запросов
    poolclass=NullPool,  # Отключаем пул соединений для простоты
)

# Создаем фабрику сессий
async_session_maker = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)


async def init_db():
    """
    Инициализация базы данных
    Создает все таблицы, если их нет
    """
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def get_session() -> AsyncSession:
    """
    Получить сессию базы данных
    """
    async with async_session_maker() as session:
        yield session
