"""
Обработчики для админ-панели
Управление бизнесами, услугами, сотрудниками и записями
"""
from datetime import datetime, timedelta
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, func
from sqlalchemy.orm import selectinload

from database import async_session_maker, Booking
from database.crud import (
    get_or_create_user,
    get_user_businesses,
    create_business,
    create_service,
    create_employee,
    get_business_services,
    get_business_employees,
    get_business_bookings,
    update_booking_status,
    get_business_by_id,
    get_employee_by_telegram_id
)
from bot.states import BusinessCreationStates, ServiceCreationStates, EmployeeCreationStates, BusinessEditStates, ServiceEditStates, EmployeeEditStates
from bot.keyboards import admin_kb, client_kb

router = Router()


# ===== ПРОСМОТР БИЗНЕСОВ =====

@router.message(F.text == "🏢 Мои бизнесы")
async def show_my_businesses(message: Message, state: FSMContext):
    """Показать бизнесы пользователя"""
    # Очищаем FSM состояние при возврате к списку бизнесов
    await state.clear()

    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name
        )

        businesses = await get_user_businesses(session, user.id)

    if not businesses:
        from aiogram.utils.keyboard import InlineKeyboardBuilder
        builder = InlineKeyboardBuilder()
        builder.button(text="🏠 Главное меню", callback_data="main_menu")
        builder.adjust(1)

        await message.answer(
            "У вас пока нет ни одного бизнеса.\n"
            "Используйте '➕ Добавить бизнес' чтобы создать.",
            reply_markup=builder.as_markup()
        )
        return

    await message.answer(
        "Ваши бизнесы:",
        reply_markup=admin_kb.get_businesses_admin_keyboard(businesses)
    )


@router.callback_query(F.data == "admin_back_to_list")
async def admin_back_to_businesses(callback: CallbackQuery, state: FSMContext):
    """Возврат к списку бизнесов (обработчик callback кнопки для админа)"""
    # Очищаем FSM состояние при возврате
    await state.clear()

    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            telegram_id=callback.from_user.id,
            username=callback.from_user.username,
            full_name=callback.from_user.full_name
        )

        businesses = await get_user_businesses(session, user.id)

    if not businesses:
        from aiogram.utils.keyboard import InlineKeyboardBuilder
        builder = InlineKeyboardBuilder()
        builder.button(text="🏠 Главное меню", callback_data="main_menu")
        builder.adjust(1)

        await callback.message.edit_text(
            "У вас пока нет ни одного бизнеса.\n"
            "Используйте '➕ Добавить бизнес' чтобы создать.",
            reply_markup=builder.as_markup()
        )
        await callback.answer()
        return

    await callback.message.edit_text(
        "Ваши бизнесы:",
        reply_markup=admin_kb.get_businesses_admin_keyboard(businesses)
    )
    await callback.answer()


# ===== СОЗДАНИЕ БИЗНЕСА =====

@router.message(F.text == "➕ Добавить бизнес")
@router.callback_query(F.data == "create_business")
async def start_business_creation(event, state: FSMContext):
    """Начало создания бизнеса"""
    message = event.message if isinstance(event, CallbackQuery) else event

    await message.answer(
        "Создание нового бизнеса\n\n"
        "Введите название вашего бизнеса:"
    )
    await state.set_state(BusinessCreationStates.entering_name)

    if isinstance(event, CallbackQuery):
        await event.answer()


@router.message(BusinessCreationStates.entering_name)
async def business_name_entered(message: Message, state: FSMContext):
    """Получение названия бизнеса"""
    await state.update_data(name=message.text)

    await message.answer(
        "Выберите тип бизнеса:",
        reply_markup=admin_kb.get_business_types_keyboard()
    )
    await state.set_state(BusinessCreationStates.entering_type)


@router.callback_query(F.data.startswith("business_type:"), BusinessCreationStates.entering_type)
async def business_type_chosen(callback: CallbackQuery, state: FSMContext):
    """Выбор типа бизнеса"""
    business_type = callback.data.split(":")[1]

    # Получаем шаблон для этого типа бизнеса
    from bot.utils.business_templates import get_template
    template = get_template(business_type)

    # Автоматически применяем шаблон
    await state.update_data(
        business_type=business_type,
        description=template["description"],
        working_hours_start=template["working_hours_start"],
        working_hours_end=template["working_hours_end"],
        break_start=template["break_start"],
        break_end=template["break_end"],
        booking_interval_minutes=template["booking_interval_minutes"]
    )

    template_info = f"""
✅ Применен шаблон "{template['name']}"

⏰ Время работы: {template['working_hours_start'].strftime('%H:%M')}-{template['working_hours_end'].strftime('%H:%M')}
"""
    if template['break_start'] and template['break_end']:
        template_info += f"☕ Перерыв: {template['break_start'].strftime('%H:%M')}-{template['break_end'].strftime('%H:%M')}\n"

    template_info += f"""📊 Шаг записи: {template['booking_interval_minutes']} мин

Теперь введите описание бизнеса
(или '-' чтобы использовать описание из шаблона):"""

    await callback.message.edit_text(template_info)
    await state.set_state(BusinessCreationStates.entering_description)
    await callback.answer()


@router.message(BusinessCreationStates.entering_description)
async def business_description_entered(message: Message, state: FSMContext):
    """Получение описания"""
    # Если пользователь не ввел "-", обновляем описание
    if message.text != "-":
        await state.update_data(description=message.text)

    # Шаблон уже заполнил время работы, перерыв и интервал
    # Переходим сразу к адресу
    await message.answer(
        "Введите адрес бизнеса (или '-' чтобы пропустить):"
    )
    await state.set_state(BusinessCreationStates.entering_address)


@router.message(BusinessCreationStates.entering_address)
async def business_address_entered(message: Message, state: FSMContext):
    """Получение адреса"""
    address = None if message.text == "-" else message.text
    await state.update_data(address=address)

    await message.answer(
        "Введите телефон для связи (или '-' чтобы пропустить):"
    )
    await state.set_state(BusinessCreationStates.entering_phone)


@router.message(BusinessCreationStates.entering_phone)
async def business_phone_entered(message: Message, state: FSMContext):
    """Получение телефона"""
    from bot.utils.validators import validate_phone

    phone = None
    if message.text != "-":
        if not validate_phone(message.text):
            await message.answer(
                "❌ Неверный формат телефона!\n"
                "Используйте формат: +7XXXXXXXXXX или 8XXXXXXXXXX\n\n"
                "Попробуйте снова или '-' чтобы пропустить:"
            )
            return
        phone = message.text

    await state.update_data(phone=phone)

    # Создаем бизнес с данными из шаблона
    data = await state.get_data()

    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name
        )

        business = await create_business(
            session,
            owner_id=user.id,
            name=data['name'],
            business_type=data['business_type'],
            description=data.get('description'),
            address=data.get('address'),
            phone=data.get('phone'),
            working_hours_start=data.get('working_hours_start'),
            working_hours_end=data.get('working_hours_end'),
            break_start=data.get('break_start'),
            break_end=data.get('break_end'),
            booking_interval_minutes=data.get('booking_interval_minutes', 30)
        )

    # Получаем роли для клавиатуры
    async with async_session_maker() as session:
        employee = await get_employee_by_telegram_id(session, message.from_user.id)

    await message.answer(
        f"✅ Бизнес '{business.name}' успешно создан!\n\n"
        f"⏰ Время работы: {business.working_hours_start.strftime('%H:%M') if business.working_hours_start else 'не указано'}-"
        f"{business.working_hours_end.strftime('%H:%M') if business.working_hours_end else 'не указано'}\n"
        f"📊 Шаг записи: {business.booking_interval_minutes} мин",
        reply_markup=admin_kb.get_admin_menu_keyboard(show_master_button=(employee is not None), is_super_admin=(message.from_user.id == 437862772))
    )

    await state.clear()


@router.message(BusinessCreationStates.entering_working_hours)
async def business_working_hours_entered(message: Message, state: FSMContext):
    """Получение времени работы"""
    from datetime import time

    working_hours_start = None
    working_hours_end = None

    if message.text != "-":
        try:
            # Парсим время в формате "09:00-18:00"
            times = message.text.split("-")
            if len(times) == 2:
                start_hour, start_min = map(int, times[0].strip().split(":"))
                end_hour, end_min = map(int, times[1].strip().split(":"))
                working_hours_start = time(start_hour, start_min)
                working_hours_end = time(end_hour, end_min)
        except (ValueError, IndexError):
            await message.answer(
                "❌ Неверный формат времени!\n"
                "Используйте формат: 09:00-18:00\n\n"
                "Попробуйте снова или отправьте '-' чтобы пропустить:"
            )
            return

    await state.update_data(
        working_hours_start=working_hours_start,
        working_hours_end=working_hours_end
    )

    await message.answer(
        "Введите время перерыва (обед) в формате:\n"
        "<b>13:00-14:00</b>\n\n"
        "Или '-' если перерыва нет:",
        parse_mode="HTML"
    )
    await state.set_state(BusinessCreationStates.entering_break_time)


@router.message(BusinessCreationStates.entering_break_time)
async def business_break_time_entered(message: Message, state: FSMContext):
    """Получение времени перерыва"""
    from datetime import time

    break_start = None
    break_end = None

    if message.text != "-":
        try:
            times = message.text.split("-")
            if len(times) == 2:
                start_hour, start_min = map(int, times[0].strip().split(":"))
                end_hour, end_min = map(int, times[1].strip().split(":"))
                break_start = time(start_hour, start_min)
                break_end = time(end_hour, end_min)
        except (ValueError, IndexError):
            await message.answer(
                "❌ Неверный формат времени!\n"
                "Используйте формат: 13:00-14:00\n\n"
                "Попробуйте снова или отправьте '-' чтобы пропустить:"
            )
            return

    await state.update_data(break_start=break_start, break_end=break_end)

    await message.answer(
        "Введите шаг записи в минутах (интервал между записями):\n"
        "Например: <b>30</b> (рекомендуется)\n\n"
        "Или '-' для значения по умолчанию (30 минут):",
        parse_mode="HTML"
    )
    await state.set_state(BusinessCreationStates.entering_booking_interval)


@router.message(BusinessCreationStates.entering_booking_interval)
async def business_booking_interval_entered(message: Message, state: FSMContext):
    """Получение шага записи и создание бизнеса"""
    booking_interval = 30  # По умолчанию

    if message.text != "-":
        try:
            booking_interval = int(message.text)
            if booking_interval <= 0 or booking_interval > 240:
                await message.answer(
                    "❌ Шаг записи должен быть от 1 до 240 минут!\n"
                    "Попробуйте снова:"
                )
                return
        except ValueError:
            await message.answer(
                "❌ Введите число (минуты) или '-' для значения по умолчанию!"
            )
            return

    data = await state.get_data()

    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name
        )

        business = await create_business(
            session,
            owner_id=user.id,
            name=data['name'],
            business_type=data['business_type'],
            description=data.get('description'),
            address=data.get('address'),
            phone=data.get('phone'),
            working_hours_start=data.get('working_hours_start'),
            working_hours_end=data.get('working_hours_end'),
            break_start=data.get('break_start'),
            break_end=data.get('break_end'),
            booking_interval_minutes=booking_interval
        )

    # Формируем информацию о бизнесе
    info_text = f"""
✅ <b>Бизнес успешно создан!</b>

🏢 {business.name}
"""
    if data.get('working_hours_start') and data.get('working_hours_end'):
        info_text += f"⏰ Время работы: {data['working_hours_start'].strftime('%H:%M')}-{data['working_hours_end'].strftime('%H:%M')}\n"

    if data.get('break_start') and data.get('break_end'):
        info_text += f"🍽 Перерыв: {data['break_start'].strftime('%H:%M')}-{data['break_end'].strftime('%H:%M')}\n"

    info_text += f"📊 Шаг записи: {booking_interval} минут\n"
    info_text += "\n💡 Теперь добавьте услуги и сотрудников."

    # Клавиатура для перехода к управлению бизнесом
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="⚙️ Управление бизнесом", callback_data=f"admin_business:{business.id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await message.answer(
        info_text,
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )

    await state.clear()


# ===== СОЗДАНИЕ УСЛУГИ =====

@router.message(F.text == "➕ Добавить услугу")
async def start_service_creation(message: Message, state: FSMContext):
    """Начало создания услуги"""
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name
        )

        businesses = await get_user_businesses(session, user.id)

    if not businesses:
        await message.answer(
            "Сначала создайте бизнес!"
        )
        return

    await message.answer(
        "Выберите бизнес, к которому добавить услугу:",
        reply_markup=admin_kb.get_businesses_admin_keyboard(businesses, "add_service_to")
    )
    await state.set_state(ServiceCreationStates.choosing_business)


@router.callback_query(F.data.startswith("add_service_to:"))
async def add_service_to_business(callback: CallbackQuery, state: FSMContext):
    """Добавление услуги к бизнесу (прямой вход)"""
    business_id = int(callback.data.split(":")[1])

    # Проверка прав доступа
    from database import is_business_owner
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этим бизнесом", show_alert=True)
            return

    await state.update_data(business_id=business_id)

    await callback.message.edit_text(
        "Введите название услуги:"
    )
    await state.set_state(ServiceCreationStates.entering_name)
    await callback.answer()


@router.callback_query(F.data.startswith("add_service_to:"), ServiceCreationStates.choosing_business)
async def business_for_service_chosen(callback: CallbackQuery, state: FSMContext):
    """Выбор бизнеса для услуги"""
    business_id = int(callback.data.split(":")[1])

    # Проверка прав доступа
    from database import is_business_owner, async_session_maker, get_or_create_user
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этим бизнесом", show_alert=True)
            return

    await state.update_data(business_id=business_id)

    await callback.message.edit_text(
        "Введите название услуги:"
    )
    await state.set_state(ServiceCreationStates.entering_name)
    await callback.answer()


@router.message(ServiceCreationStates.entering_name)
async def service_name_entered(message: Message, state: FSMContext):
    """Получение названия услуги"""
    await state.update_data(name=message.text)

    await message.answer(
        "Введите описание услуги (или '-' чтобы пропустить):"
    )
    await state.set_state(ServiceCreationStates.entering_description)


@router.message(ServiceCreationStates.entering_description)
async def service_description_entered(message: Message, state: FSMContext):
    """Получение описания услуги"""
    description = None if message.text == "-" else message.text
    await state.update_data(description=description)

    await message.answer(
        "Введите длительность услуги в минутах (например: 60):"
    )
    await state.set_state(ServiceCreationStates.entering_duration)


@router.message(ServiceCreationStates.entering_duration)
async def service_duration_entered(message: Message, state: FSMContext):
    """Получение длительности"""
    from bot.utils.validators import validate_duration

    is_valid, duration = validate_duration(message.text)
    if not is_valid:
        await message.answer(
            "❌ Введите корректное число от 1 до 480 минут (до 8 часов):"
        )
        return

    await state.update_data(duration_minutes=duration)

    await message.answer(
        "Введите цену в рублях (или '-' чтобы пропустить):"
    )
    await state.set_state(ServiceCreationStates.entering_price)


@router.message(ServiceCreationStates.entering_price)
async def service_price_entered(message: Message, state: FSMContext):
    """Получение цены и создание услуги"""
    from bot.utils.validators import validate_price

    price = None
    if message.text != "-":
        is_valid, price_value = validate_price(message.text)
        if not is_valid:
            await message.answer(
                "❌ Введите корректную цену от 0 до 1000000 рублей или '-' чтобы пропустить:"
            )
            return
        price = price_value

    data = await state.get_data()
    business_id = data['business_id']

    async with async_session_maker() as session:
        service = await create_service(
            session,
            business_id=business_id,
            name=data['name'],
            duration_minutes=data['duration_minutes'],
            description=data.get('description'),
            price=price
        )

    # Формируем информацию об услуге
    info_text = f"""
✅ <b>Услуга успешно создана!</b>

📋 {service.name}
⏱ Длительность: {service.duration_minutes} мин
"""
    if service.price:
        info_text += f"💰 Цена: {service.price} ₽\n"
    if service.description:
        info_text += f"\n📝 {service.description}"

    # Клавиатура для возврата к списку услуг
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="◀️ К списку услуг", callback_data=f"manage_services:{business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await message.answer(
        info_text,
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )

    await state.clear()


# ===== СОЗДАНИЕ СОТРУДНИКА =====

@router.message(F.text == "👥 Добавить сотрудника")
async def start_employee_creation(message: Message, state: FSMContext):
    """Начало создания сотрудника"""
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name
        )

        businesses = await get_user_businesses(session, user.id)

    if not businesses:
        await message.answer("Сначала создайте бизнес!")
        return

    await message.answer(
        "Выберите бизнес, к которому добавить сотрудника:",
        reply_markup=admin_kb.get_businesses_admin_keyboard(businesses, "add_employee_to")
    )
    await state.set_state(EmployeeCreationStates.choosing_business)


@router.callback_query(F.data.startswith("add_employee_to:"))
async def add_employee_to_business(callback: CallbackQuery, state: FSMContext):
    """Добавление сотрудника к бизнесу (прямой вход)"""
    business_id = int(callback.data.split(":")[1])

    # Проверка прав доступа
    from database import is_business_owner
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этим бизнесом", show_alert=True)
            return

    await state.update_data(business_id=business_id)

    await callback.message.edit_text(
        "Введите имя сотрудника:"
    )
    await state.set_state(EmployeeCreationStates.entering_name)
    await callback.answer()


@router.callback_query(F.data.startswith("add_employee_to:"), EmployeeCreationStates.choosing_business)
async def business_for_employee_chosen(callback: CallbackQuery, state: FSMContext):
    """Выбор бизнеса для сотрудника"""
    business_id = int(callback.data.split(":")[1])

    # Проверка прав доступа
    from database import is_business_owner, async_session_maker, get_or_create_user
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этим бизнесом", show_alert=True)
            return

    await state.update_data(business_id=business_id)

    await callback.message.edit_text(
        "Введите имя сотрудника:"
    )
    await state.set_state(EmployeeCreationStates.entering_name)
    await callback.answer()


@router.message(EmployeeCreationStates.entering_name)
async def employee_name_entered(message: Message, state: FSMContext):
    """Получение имени сотрудника"""
    await state.update_data(name=message.text)

    await message.answer(
        "Введите специализацию (или '-' чтобы пропустить):"
    )
    await state.set_state(EmployeeCreationStates.entering_specialization)


@router.message(EmployeeCreationStates.entering_specialization)
async def employee_specialization_entered(message: Message, state: FSMContext):
    """Получение специализации"""
    specialization = None if message.text == "-" else message.text
    await state.update_data(specialization=specialization)

    await message.answer(
        "Введите Telegram ID сотрудника:\n\n"
        "⚠️ <b>Важно!</b> Telegram ID нужен для:\n"
        "• Доступа мастера к своему профилю\n"
        "• Возможности создавать записи\n"
        "• Получения уведомлений о новых записях\n\n"
        "🔍 Узнать ID можно у бота @userinfobot\n"
        "Или '-' чтобы пропустить (мастер не сможет войти в профиль):",
        parse_mode="HTML"
    )
    await state.set_state(EmployeeCreationStates.entering_telegram_id)


@router.message(EmployeeCreationStates.entering_telegram_id)
async def employee_telegram_id_entered(message: Message, state: FSMContext):
    """Получение Telegram ID сотрудника"""
    telegram_id = None

    if message.text != "-":
        try:
            telegram_id = int(message.text)
            if telegram_id <= 0:
                await message.answer(
                    "❌ Telegram ID должен быть положительным числом!\n"
                    "Попробуйте снова или '-' чтобы пропустить:"
                )
                return
        except ValueError:
            await message.answer(
                "❌ Введите корректный Telegram ID (число) или '-' чтобы пропустить:"
            )
            return

    await state.update_data(telegram_id=telegram_id)

    await message.answer(
        "Введите индивидуальный шаг записи для этого сотрудника (в минутах):\n"
        "Например: <b>45</b>\n\n"
        "Или '-' чтобы использовать общий шаг салона:",
        parse_mode="HTML"
    )
    await state.set_state(EmployeeCreationStates.entering_booking_interval)


@router.message(EmployeeCreationStates.entering_booking_interval)
async def employee_booking_interval_entered(message: Message, state: FSMContext):
    """Получение шага записи и создание сотрудника"""
    booking_interval = None

    if message.text != "-":
        try:
            booking_interval = int(message.text)
            if booking_interval <= 0 or booking_interval > 240:
                await message.answer(
                    "❌ Шаг записи должен быть от 1 до 240 минут!\n"
                    "Попробуйте снова или '-' для общего шага:"
                )
                return
        except ValueError:
            await message.answer(
                "❌ Введите число (минуты) или '-' для общего шага салона!"
            )
            return

    data = await state.get_data()
    business_id = data['business_id']

    async with async_session_maker() as session:
        employee = await create_employee(
            session,
            business_id=business_id,
            name=data['name'],
            specialization=data.get('specialization'),
            telegram_id=data.get('telegram_id'),
            booking_interval_minutes=booking_interval
        )

    # Формируем информацию о сотруднике
    info_text = f"""
✅ <b>Сотрудник успешно добавлен!</b>

👔 {employee.name}
"""
    if employee.specialization:
        info_text += f"💼 Специализация: {employee.specialization}\n"

    if employee.telegram_id:
        info_text += f"📱 Telegram ID: {employee.telegram_id}\n"
    else:
        info_text += "⚠️ <b>Telegram ID не указан</b> - мастер не сможет войти в профиль\n"

    if booking_interval:
        info_text += f"📊 Шаг записи: {booking_interval} минут\n"
    else:
        info_text += "📊 Используется общий шаг бизнеса\n"

    # Клавиатура для возврата к списку сотрудников
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="◀️ К списку сотрудников", callback_data=f"manage_employees:{business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await message.answer(
        info_text,
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )

    await state.clear()


# ===== ПРОСМОТР ЗАПИСЕЙ =====

@router.message(F.text == "📊 Записи")
async def show_bookings(message: Message):
    """Показать выбор бизнеса для просмотра записей"""
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name
        )

        businesses = await get_user_businesses(session, user.id)

        if not businesses:
            from aiogram.utils.keyboard import InlineKeyboardBuilder
            builder = InlineKeyboardBuilder()
            builder.button(text="🏠 Главное меню", callback_data="main_menu")
            builder.adjust(1)

            await message.answer(
                "У вас нет бизнесов!",
                reply_markup=builder.as_markup()
            )
            return

    await message.answer(
        "Выберите бизнес для просмотра записей:",
        reply_markup=admin_kb.get_businesses_admin_keyboard(businesses, "view_bookings")
    )


# ===== УПРАВЛЕНИЕ БИЗНЕСОМ =====

@router.callback_query(F.data.startswith("admin_business:"))
async def manage_business(callback: CallbackQuery, state: FSMContext):
    """Управление бизнесом"""
    business_id = int(callback.data.split(":")[1])

    # ВАЖНО: Очищаем FSM состояние при входе в управление бизнесом
    await state.clear()

    # Проверка прав доступа
    from database import is_business_owner, get_or_create_user
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этим бизнесом", show_alert=True)
            return

        business = await get_business_by_id(session, business_id)

    info_text = f"""
🏢 <b>{business.name}</b>

Тип: {business.business_type}
{f'📍 Адрес: {business.address}' if business.address else ''}
{f'📞 Телефон: {business.phone}' if business.phone else ''}
Статус: {'✅ Активен' if business.is_active else '⏸ Неактивен'}

Выберите действие:
"""

    await callback.message.edit_text(
        info_text,
        parse_mode="HTML",
        reply_markup=admin_kb.get_business_management_keyboard(business_id)
    )
    await callback.answer()


@router.callback_query(F.data.startswith("delete_business:"))
async def delete_business_confirm(callback: CallbackQuery):
    """Запрос подтверждения удаления бизнеса"""
    business_id = int(callback.data.split(":")[1])

    # Проверка прав доступа
    from database import is_business_owner, get_or_create_user
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этим бизнесом", show_alert=True)
            return

        business = await get_business_by_id(session, business_id)
        business_name = business.name

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Да, удалить навсегда", callback_data=f"confirm_delete_business:{business_id}")
    builder.button(text="❌ Отмена", callback_data=f"admin_business:{business_id}")
    builder.adjust(1)

    await callback.message.edit_text(
        f"⚠️ <b>ВНИМАНИЕ!</b>\n\n"
        f"Вы уверены, что хотите удалить бизнес '{business_name}'?\n\n"
        f"Будут удалены:\n"
        f"• Все услуги\n"
        f"• Все сотрудники\n"
        f"• Все записи клиентов\n\n"
        f"Это действие необратимо!",
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("confirm_delete_business:"))
async def delete_business_confirmed(callback: CallbackQuery):
    """Окончательное удаление бизнеса"""
    business_id = int(callback.data.split(":")[1])

    # Проверка прав доступа
    from database import is_business_owner, get_or_create_user
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этим бизнесом", show_alert=True)
            return

        business = await get_business_by_id(session, business_id)
        business_name = business.name

        # Удаляем бизнес (cascade удалит все связанные записи)
        await session.delete(business)
        await session.commit()

    await callback.answer(f"✅ Бизнес '{business_name}' удалён", show_alert=True)

    # Возвращаемся к списку бизнесов
    async with async_session_maker() as session:
        businesses = await get_user_businesses(session, user.id)
        employee = await get_employee_by_telegram_id(session, callback.from_user.id)

    if businesses:
        await callback.message.edit_text(
            "Ваши бизнесы:",
            reply_markup=admin_kb.get_businesses_admin_keyboard(businesses)
        )
    else:
        await callback.message.edit_text(
            "У вас больше нет бизнесов.\n\n"
            "Создайте новый бизнес, чтобы начать работу.",
            reply_markup=admin_kb.get_admin_menu_keyboard(show_master_button=(employee is not None), is_super_admin=(callback.from_user.id == 437862772))
        )


@router.callback_query(F.data.startswith("manage_services:"))
async def manage_services(callback: CallbackQuery, state: FSMContext):
    """Управление услугами бизнеса"""
    business_id = int(callback.data.split(":")[1])

    # ВАЖНО: Очищаем FSM при возврате к списку услуг
    await state.clear()

    # Проверка прав доступа
    from database import is_business_owner, get_or_create_user
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этим бизнесом", show_alert=True)
            return

        business = await get_business_by_id(session, business_id)
        services = await get_business_services(session, business_id)

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()

    if not services:
        info_text = f"""
🏢 <b>{business.name}</b>
📋 <b>Услуги</b>

Услуги пока не добавлены
"""
    else:
        info_text = f"""
🏢 <b>{business.name}</b>
📋 <b>Услуги</b>

Выберите услугу для редактирования или удаления:
"""
        for service in services:
            builder.button(
                text=f"📋 {service.name} ({service.duration_minutes} мин, {service.price} ₽)",
                callback_data=f"edit_service:{service.id}"
            )

    builder.button(text="➕ Добавить услугу", callback_data=f"add_service_to:{business_id}")
    builder.button(text="◀️ Назад", callback_data=f"admin_business:{business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await callback.message.edit_text(
        info_text,
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("manage_employees:"))
async def manage_employees(callback: CallbackQuery, state: FSMContext):
    """Управление сотрудниками бизнеса"""
    business_id = int(callback.data.split(":")[1])

    # ВАЖНО: Очищаем FSM при возврате к списку сотрудников
    await state.clear()

    # Проверка прав доступа
    from database import is_business_owner, get_or_create_user
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этим бизнесом", show_alert=True)
            return

        business = await get_business_by_id(session, business_id)
        employees = await get_business_employees(session, business_id)

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()

    if not employees:
        info_text = f"""
🏢 <b>{business.name}</b>
👥 <b>Сотрудники</b>

Сотрудники пока не добавлены
"""
    else:
        info_text = f"""
🏢 <b>{business.name}</b>
👥 <b>Сотрудники</b>

Выберите сотрудника для редактирования или удаления:
"""
        for employee in employees:
            builder.button(
                text=f"👤 {employee.name} ({employee.specialization})",
                callback_data=f"edit_employee:{employee.id}"
            )

    builder.button(text="➕ Добавить сотрудника", callback_data=f"add_employee_to:{business_id}")
    builder.button(text="◀️ Назад", callback_data=f"admin_business:{business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await callback.message.edit_text(
        info_text,
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("edit_service:"))
async def edit_service_menu(callback: CallbackQuery):
    """Меню редактирования услуги"""
    service_id = int(callback.data.split(":")[1])

    from database.crud import get_service_by_id
    async with async_session_maker() as session:
        service = await get_service_by_id(session, service_id)
        business = await get_business_by_id(session, service.business_id)

    info_text = f"""
📋 <b>{service.name}</b>

🏢 Бизнес: {business.name}
⏱ Длительность: {service.duration_minutes} мин
💰 Цена: {service.price} ₽
📝 Описание: {service.description if service.description else '(не указано)'}

Выберите действие:
"""

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Редактировать название", callback_data=f"edit_service_name:{service_id}")
    builder.button(text="⏱ Редактировать длительность", callback_data=f"edit_service_duration:{service_id}")
    builder.button(text="💰 Редактировать цену", callback_data=f"edit_service_price:{service_id}")
    builder.button(text="📝 Редактировать описание", callback_data=f"edit_service_description:{service_id}")
    builder.button(text="🗑 Удалить услугу", callback_data=f"delete_service:{service_id}")
    builder.button(text="◀️ Назад", callback_data=f"manage_services:{service.business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await callback.message.edit_text(
        info_text,
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("delete_service:"))
async def delete_service_confirm(callback: CallbackQuery):
    """Запрос подтверждения удаления услуги"""
    service_id = int(callback.data.split(":")[1])

    from database.crud import get_service_by_id
    async with async_session_maker() as session:
        service = await get_service_by_id(session, service_id)
        service_name = service.name

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Да, удалить", callback_data=f"confirm_delete_service:{service_id}")
    builder.button(text="❌ Отмена", callback_data=f"edit_service:{service_id}")
    builder.adjust(1)

    await callback.message.edit_text(
        f"⚠️ Вы уверены, что хотите удалить услугу '{service_name}'?\n\n"
        "Это действие необратимо!",
        reply_markup=builder.as_markup()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("confirm_delete_service:"))
async def delete_service_confirmed(callback: CallbackQuery):
    """Окончательное удаление услуги"""
    service_id = int(callback.data.split(":")[1])

    from database.crud import get_service_by_id, delete_service
    async with async_session_maker() as session:
        service = await get_service_by_id(session, service_id)
        business_id = service.business_id
        service_name = service.name

        await delete_service(session, service_id)

    await callback.answer(f"✅ Услуга '{service_name}' удалена", show_alert=True)

    # Возвращаемся в список услуг
    from database import is_business_owner, get_or_create_user
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        business = await get_business_by_id(session, business_id)
        services = await get_business_services(session, business_id)

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()

    if not services:
        info_text = f"""
🏢 <b>{business.name}</b>
📋 <b>Услуги</b>

Услуги пока не добавлены
"""
    else:
        info_text = f"""
🏢 <b>{business.name}</b>
📋 <b>Услуги</b>

Выберите услугу для редактирования или удаления:
"""
        for svc in services:
            builder.button(
                text=f"📋 {svc.name} ({svc.duration} мин, {svc.price} ₽)",
                callback_data=f"edit_service:{svc.id}"
            )

    builder.button(text="➕ Добавить услугу", callback_data=f"add_service_to:{business_id}")
    builder.button(text="◀️ Назад", callback_data=f"admin_business:{business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await callback.message.edit_text(
        info_text,
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )


@router.callback_query(F.data.startswith("edit_employee:"))
async def edit_employee_menu(callback: CallbackQuery):
    """Меню редактирования сотрудника"""
    employee_id = int(callback.data.split(":")[1])

    from database.crud import get_employee_by_id
    async with async_session_maker() as session:
        employee = await get_employee_by_id(session, employee_id)
        business = await get_business_by_id(session, employee.business_id)

    info_text = f"""
👤 <b>{employee.name}</b>

🏢 Бизнес: {business.name}
💼 Специализация: {employee.specialization}
📅 Интервал записи: {employee.booking_interval_minutes} мин
{f'📱 Telegram ID: {employee.telegram_id}' if employee.telegram_id else ''}

Выберите действие:
"""

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Редактировать имя", callback_data=f"edit_employee_name:{employee_id}")
    builder.button(text="💼 Редактировать специализацию", callback_data=f"edit_employee_spec:{employee_id}")
    builder.button(text="📱 Редактировать Telegram ID", callback_data=f"edit_employee_telegram:{employee_id}")
    builder.button(text="📅 Редактировать интервал", callback_data=f"edit_employee_interval:{employee_id}")
    builder.button(text="🗑 Удалить сотрудника", callback_data=f"delete_employee:{employee_id}")
    builder.button(text="◀️ Назад", callback_data=f"manage_employees:{employee.business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await callback.message.edit_text(
        info_text,
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("delete_employee:"))
async def delete_employee_confirm(callback: CallbackQuery):
    """Подтверждение удаления сотрудника"""
    employee_id = int(callback.data.split(":")[1])

    from database.crud import get_employee_by_id, delete_employee
    async with async_session_maker() as session:
        employee = await get_employee_by_id(session, employee_id)
        business_id = employee.business_id
        employee_name = employee.name

        await delete_employee(session, employee_id)

    await callback.answer(f"✅ Сотрудник '{employee_name}' удалён", show_alert=True)

    # Возвращаемся в список сотрудников
    from database import is_business_owner, get_or_create_user
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        business = await get_business_by_id(session, business_id)
        employees = await get_business_employees(session, business_id)

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()

    if not employees:
        info_text = f"""
🏢 <b>{business.name}</b>
👥 <b>Сотрудники</b>

Сотрудники пока не добавлены
"""
    else:
        info_text = f"""
🏢 <b>{business.name}</b>
👥 <b>Сотрудники</b>

Выберите сотрудника для редактирования или удаления:
"""
        for emp in employees:
            builder.button(
                text=f"👤 {emp.name} ({emp.specialization})",
                callback_data=f"edit_employee:{emp.id}"
            )

    builder.button(text="➕ Добавить сотрудника", callback_data=f"add_employee_to:{business_id}")
    builder.button(text="◀️ Назад", callback_data=f"admin_business:{business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await callback.message.edit_text(
        info_text,
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )


# ===== РЕДАКТИРОВАНИЕ УСЛУГ =====

@router.callback_query(F.data.startswith("edit_service_name:"))
async def edit_service_name_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования названия услуги"""
    service_id = int(callback.data.split(":")[1])
    await state.update_data(service_id=service_id)

    await callback.message.edit_text("Введите новое название услуги:")
    await state.set_state(ServiceEditStates.editing_name)
    await callback.answer()


@router.message(ServiceEditStates.editing_name)
async def edit_service_name_save(message: Message, state: FSMContext):
    """Сохранение нового названия услуги"""
    data = await state.get_data()
    service_id = data['service_id']

    from database.crud import get_service_by_id
    async with async_session_maker() as session:
        service = await get_service_by_id(session, service_id)
        service.name = message.text
        await session.commit()
        await session.refresh(service)

        business = await get_business_by_id(session, service.business_id)

    info_text = f"""
📋 <b>{service.name}</b>

🏢 Бизнес: {business.name}
⏱ Длительность: {service.duration_minutes} мин
💰 Цена: {service.price} ₽
📝 Описание: {service.description if service.description else '(не указано)'}

✅ Название успешно изменено на: <b>{message.text}</b>

Выберите действие:
"""

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Редактировать название", callback_data=f"edit_service_name:{service_id}")
    builder.button(text="⏱ Редактировать длительность", callback_data=f"edit_service_duration:{service_id}")
    builder.button(text="💰 Редактировать цену", callback_data=f"edit_service_price:{service_id}")
    builder.button(text="📝 Редактировать описание", callback_data=f"edit_service_description:{service_id}")
    builder.button(text="🗑 Удалить услугу", callback_data=f"delete_service:{service_id}")
    builder.button(text="◀️ Назад", callback_data=f"manage_services:{service.business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await message.answer(info_text, parse_mode="HTML", reply_markup=builder.as_markup())
    await state.clear()


@router.callback_query(F.data.startswith("edit_service_duration:"))
async def edit_service_duration_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования длительности услуги"""
    service_id = int(callback.data.split(":")[1])
    await state.update_data(service_id=service_id)

    await callback.message.edit_text("Введите новую длительность услуги (в минутах):")
    await state.set_state(ServiceEditStates.editing_duration)
    await callback.answer()


@router.message(ServiceEditStates.editing_duration)
async def edit_service_duration_save(message: Message, state: FSMContext):
    """Сохранение новой длительности услуги"""
    data = await state.get_data()
    service_id = data['service_id']

    try:
        duration = int(message.text)
        if duration <= 0:
            raise ValueError
    except ValueError:
        await message.answer("❌ Ошибка! Введите корректное число минут (например: 30, 60, 90)")
        return

    from database.crud import get_service_by_id
    async with async_session_maker() as session:
        service = await get_service_by_id(session, service_id)
        service.duration_minutes = duration
        await session.commit()
        await session.refresh(service)

        business = await get_business_by_id(session, service.business_id)

    info_text = f"""
📋 <b>{service.name}</b>

🏢 Бизнес: {business.name}
⏱ Длительность: {service.duration_minutes} мин
💰 Цена: {service.price} ₽
📝 Описание: {service.description if service.description else '(не указано)'}

✅ Длительность успешно изменена на: <b>{duration} мин</b>

Выберите действие:
"""

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Редактировать название", callback_data=f"edit_service_name:{service_id}")
    builder.button(text="⏱ Редактировать длительность", callback_data=f"edit_service_duration:{service_id}")
    builder.button(text="💰 Редактировать цену", callback_data=f"edit_service_price:{service_id}")
    builder.button(text="📝 Редактировать описание", callback_data=f"edit_service_description:{service_id}")
    builder.button(text="🗑 Удалить услугу", callback_data=f"delete_service:{service_id}")
    builder.button(text="◀️ Назад", callback_data=f"manage_services:{service.business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await message.answer(info_text, parse_mode="HTML", reply_markup=builder.as_markup())
    await state.clear()


@router.callback_query(F.data.startswith("edit_service_price:"))
async def edit_service_price_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования цены услуги"""
    service_id = int(callback.data.split(":")[1])
    await state.update_data(service_id=service_id)

    await callback.message.edit_text("Введите новую цену услуги (в рублях):")
    await state.set_state(ServiceEditStates.editing_price)
    await callback.answer()


@router.message(ServiceEditStates.editing_price)
async def edit_service_price_save(message: Message, state: FSMContext):
    """Сохранение новой цены услуги"""
    data = await state.get_data()
    service_id = data['service_id']

    try:
        price = float(message.text.replace(',', '.'))
        if price < 0:
            raise ValueError
    except ValueError:
        await message.answer("❌ Ошибка! Введите корректную цену (например: 1000, 1500.50)")
        return

    from database.crud import get_service_by_id
    async with async_session_maker() as session:
        service = await get_service_by_id(session, service_id)
        service.price = price
        await session.commit()
        await session.refresh(service)

        business = await get_business_by_id(session, service.business_id)

    info_text = f"""
📋 <b>{service.name}</b>

🏢 Бизнес: {business.name}
⏱ Длительность: {service.duration_minutes} мин
💰 Цена: {service.price} ₽
📝 Описание: {service.description if service.description else '(не указано)'}

✅ Цена успешно изменена на: <b>{price} ₽</b>

Выберите действие:
"""

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Редактировать название", callback_data=f"edit_service_name:{service_id}")
    builder.button(text="⏱ Редактировать длительность", callback_data=f"edit_service_duration:{service_id}")
    builder.button(text="💰 Редактировать цену", callback_data=f"edit_service_price:{service_id}")
    builder.button(text="📝 Редактировать описание", callback_data=f"edit_service_description:{service_id}")
    builder.button(text="🗑 Удалить услугу", callback_data=f"delete_service:{service_id}")
    builder.button(text="◀️ Назад", callback_data=f"manage_services:{service.business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await message.answer(info_text, parse_mode="HTML", reply_markup=builder.as_markup())
    await state.clear()


@router.callback_query(F.data.startswith("edit_service_description:"))
async def edit_service_description_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования описания услуги"""
    service_id = int(callback.data.split(":")[1])
    await state.update_data(service_id=service_id)

    await callback.message.edit_text("Введите новое описание услуги (или '-' для удаления):")
    await state.set_state(ServiceEditStates.editing_description)
    await callback.answer()


@router.message(ServiceEditStates.editing_description)
async def edit_service_description_save(message: Message, state: FSMContext):
    """Сохранение нового описания услуги"""
    data = await state.get_data()
    service_id = data['service_id']

    description = None if message.text == "-" else message.text

    from database.crud import get_service_by_id
    async with async_session_maker() as session:
        service = await get_service_by_id(session, service_id)
        service.description = description
        await session.commit()
        await session.refresh(service)

        business = await get_business_by_id(session, service.business_id)

    description_display = description if description else "(не указано)"

    info_text = f"""
📋 <b>{service.name}</b>

🏢 Бизнес: {business.name}
⏱ Длительность: {service.duration_minutes} мин
💰 Цена: {service.price} ₽
📝 Описание: {service.description if service.description else '(не указано)'}

✅ Описание успешно обновлено: <i>{description_display}</i>

Выберите действие:
"""

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Редактировать название", callback_data=f"edit_service_name:{service_id}")
    builder.button(text="⏱ Редактировать длительность", callback_data=f"edit_service_duration:{service_id}")
    builder.button(text="💰 Редактировать цену", callback_data=f"edit_service_price:{service_id}")
    builder.button(text="📝 Редактировать описание", callback_data=f"edit_service_description:{service_id}")
    builder.button(text="🗑 Удалить услугу", callback_data=f"delete_service:{service_id}")
    builder.button(text="◀️ Назад", callback_data=f"manage_services:{service.business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await message.answer(info_text, parse_mode="HTML", reply_markup=builder.as_markup())
    await state.clear()


# ===== РЕДАКТИРОВАНИЕ СОТРУДНИКОВ =====

@router.callback_query(F.data.startswith("edit_employee_name:"))
async def edit_employee_name_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования имени сотрудника"""
    employee_id = int(callback.data.split(":")[1])
    await state.update_data(employee_id=employee_id)

    await callback.message.edit_text("Введите новое имя сотрудника:")
    await state.set_state(EmployeeEditStates.editing_name)
    await callback.answer()


@router.message(EmployeeEditStates.editing_name)
async def edit_employee_name_save(message: Message, state: FSMContext):
    """Сохранение нового имени сотрудника"""
    data = await state.get_data()
    employee_id = data['employee_id']

    from database.crud import get_employee_by_id
    async with async_session_maker() as session:
        employee = await get_employee_by_id(session, employee_id)
        employee.name = message.text
        await session.commit()
        await session.refresh(employee)

        business = await get_business_by_id(session, employee.business_id)

    info_text = f"""
👤 <b>{employee.name}</b>

🏢 Бизнес: {business.name}
💼 Специализация: {employee.specialization}
📅 Интервал записи: {employee.booking_interval_minutes} мин
{f'📱 Telegram ID: {employee.telegram_id}' if employee.telegram_id else ''}

✅ Имя успешно изменено на: <b>{message.text}</b>

Выберите действие:
"""

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Редактировать имя", callback_data=f"edit_employee_name:{employee_id}")
    builder.button(text="💼 Редактировать специализацию", callback_data=f"edit_employee_spec:{employee_id}")
    builder.button(text="📅 Редактировать интервал", callback_data=f"edit_employee_interval:{employee_id}")
    builder.button(text="🗑 Удалить сотрудника", callback_data=f"delete_employee:{employee_id}")
    builder.button(text="◀️ Назад", callback_data=f"manage_employees:{employee.business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await message.answer(info_text, parse_mode="HTML", reply_markup=builder.as_markup())
    await state.clear()


@router.callback_query(F.data.startswith("edit_employee_spec:"))
async def edit_employee_spec_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования специализации сотрудника"""
    employee_id = int(callback.data.split(":")[1])
    await state.update_data(employee_id=employee_id)

    await callback.message.edit_text("Введите новую специализацию сотрудника:")
    await state.set_state(EmployeeEditStates.editing_specialization)
    await callback.answer()


@router.message(EmployeeEditStates.editing_specialization)
async def edit_employee_spec_save(message: Message, state: FSMContext):
    """Сохранение новой специализации сотрудника"""
    data = await state.get_data()
    employee_id = data['employee_id']

    from database.crud import get_employee_by_id
    async with async_session_maker() as session:
        employee = await get_employee_by_id(session, employee_id)
        employee.specialization = message.text
        await session.commit()
        await session.refresh(employee)

        business = await get_business_by_id(session, employee.business_id)

    info_text = f"""
👤 <b>{employee.name}</b>

🏢 Бизнес: {business.name}
💼 Специализация: {employee.specialization}
📅 Интервал записи: {employee.booking_interval_minutes} мин
{f'📱 Telegram ID: {employee.telegram_id}' if employee.telegram_id else ''}

✅ Специализация успешно изменена на: <b>{message.text}</b>

Выберите действие:
"""

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Редактировать имя", callback_data=f"edit_employee_name:{employee_id}")
    builder.button(text="💼 Редактировать специализацию", callback_data=f"edit_employee_spec:{employee_id}")
    builder.button(text="📅 Редактировать интервал", callback_data=f"edit_employee_interval:{employee_id}")
    builder.button(text="🗑 Удалить сотрудника", callback_data=f"delete_employee:{employee_id}")
    builder.button(text="◀️ Назад", callback_data=f"manage_employees:{employee.business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await message.answer(info_text, parse_mode="HTML", reply_markup=builder.as_markup())
    await state.clear()


@router.callback_query(F.data.startswith("edit_employee_interval:"))
async def edit_employee_interval_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования интервала сотрудника"""
    employee_id = int(callback.data.split(":")[1])
    await state.update_data(employee_id=employee_id)

    await callback.message.edit_text("Введите новый интервал записи (в минутах):")
    await state.set_state(EmployeeEditStates.editing_interval)
    await callback.answer()


@router.message(EmployeeEditStates.editing_interval)
async def edit_employee_interval_save(message: Message, state: FSMContext):
    """Сохранение нового интервала сотрудника"""
    data = await state.get_data()
    employee_id = data['employee_id']

    try:
        interval = int(message.text)
        if interval <= 0:
            raise ValueError
    except ValueError:
        await message.answer("❌ Ошибка! Введите корректное число минут (например: 30, 60)")
        return

    from database.crud import get_employee_by_id
    async with async_session_maker() as session:
        employee = await get_employee_by_id(session, employee_id)
        employee.booking_interval_minutes = interval
        await session.commit()
        await session.refresh(employee)

        business = await get_business_by_id(session, employee.business_id)

    info_text = f"""
👤 <b>{employee.name}</b>

🏢 Бизнес: {business.name}
💼 Специализация: {employee.specialization}
📅 Интервал записи: {employee.booking_interval_minutes} мин
{f'📱 Telegram ID: {employee.telegram_id}' if employee.telegram_id else ''}

✅ Интервал записи успешно изменён на: <b>{interval} мин</b>

Выберите действие:
"""

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Редактировать имя", callback_data=f"edit_employee_name:{employee_id}")
    builder.button(text="💼 Редактировать специализацию", callback_data=f"edit_employee_spec:{employee_id}")
    builder.button(text="📅 Редактировать интервал", callback_data=f"edit_employee_interval:{employee_id}")
    builder.button(text="🗑 Удалить сотрудника", callback_data=f"delete_employee:{employee_id}")
    builder.button(text="◀️ Назад", callback_data=f"manage_employees:{employee.business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await message.answer(info_text, parse_mode="HTML", reply_markup=builder.as_markup())
    await state.clear()


@router.callback_query(F.data.startswith("edit_employee_telegram:"))
async def edit_employee_telegram_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования Telegram ID сотрудника"""
    employee_id = int(callback.data.split(":")[1])
    await state.update_data(employee_id=employee_id)

    await callback.message.edit_text(
        "Введите новый Telegram ID сотрудника:\n\n"
        "🔍 Узнать ID можно у бота @userinfobot\n"
        "Или '-' чтобы удалить (мастер не сможет войти в профиль):"
    )
    await state.set_state(EmployeeEditStates.editing_telegram_id)
    await callback.answer()


@router.message(EmployeeEditStates.editing_telegram_id)
async def edit_employee_telegram_save(message: Message, state: FSMContext):
    """Сохранение нового Telegram ID сотрудника"""
    data = await state.get_data()
    employee_id = data['employee_id']

    telegram_id = None
    if message.text != "-":
        try:
            telegram_id = int(message.text)
            if telegram_id <= 0:
                await message.answer(
                    "❌ Telegram ID должен быть положительным числом!\n"
                    "Попробуйте снова или '-' чтобы удалить:"
                )
                return
        except ValueError:
            await message.answer(
                "❌ Введите корректный Telegram ID (число) или '-' чтобы удалить:"
            )
            return

    from database.crud import get_employee_by_id
    async with async_session_maker() as session:
        employee = await get_employee_by_id(session, employee_id)
        employee.telegram_id = telegram_id
        await session.commit()
        await session.refresh(employee)

        business = await get_business_by_id(session, employee.business_id)

    success_msg = f"✅ Telegram ID успешно изменён на: <b>{telegram_id}</b>" if telegram_id else "✅ Telegram ID удалён"
    if not telegram_id:
        success_msg += "\n⚠️ Мастер не сможет войти в профиль"

    info_text = f"""
👤 <b>{employee.name}</b>

🏢 Бизнес: {business.name}
💼 Специализация: {employee.specialization}
📅 Интервал записи: {employee.booking_interval_minutes} мин
{f'📱 Telegram ID: {employee.telegram_id}' if employee.telegram_id else ''}

{success_msg}

Выберите действие:
"""

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Редактировать имя", callback_data=f"edit_employee_name:{employee_id}")
    builder.button(text="💼 Редактировать специализацию", callback_data=f"edit_employee_spec:{employee_id}")
    builder.button(text="📱 Редактировать Telegram ID", callback_data=f"edit_employee_telegram:{employee_id}")
    builder.button(text="📅 Редактировать интервал", callback_data=f"edit_employee_interval:{employee_id}")
    builder.button(text="🗑 Удалить сотрудника", callback_data=f"delete_employee:{employee_id}")
    builder.button(text="◀️ Назад", callback_data=f"manage_employees:{employee.business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await message.answer(info_text, parse_mode="HTML", reply_markup=builder.as_markup())
    await state.clear()


@router.callback_query(F.data == "noop")
async def noop_callback(callback: CallbackQuery):
    """Пустой обработчик для неактивных кнопок (например, номер страницы)"""
    await callback.answer()


@router.callback_query(F.data == "back_to_bookings_list")
async def back_to_bookings_list(callback: CallbackQuery):
    """Возврат к выбору бизнеса для просмотра записей"""
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            telegram_id=callback.from_user.id,
            username=callback.from_user.username,
            full_name=callback.from_user.full_name
        )
        businesses = await get_user_businesses(session, user.id)

        if not businesses:
            await callback.answer("У вас нет бизнесов", show_alert=True)
            return

    await callback.message.edit_text(
        "Выберите бизнес для просмотра записей:",
        reply_markup=admin_kb.get_businesses_admin_keyboard(businesses, "view_bookings")
    )
    await callback.answer()


@router.callback_query(F.data.startswith("view_bookings:"))
async def view_bookings(callback: CallbackQuery):
    """Просмотр записей бизнеса с выбором категории"""
    parts = callback.data.split(":")
    business_id = int(parts[1])
    category = parts[2] if len(parts) > 2 else "upcoming"
    page = int(parts[3]) if len(parts) > 3 else 0

    # Проверка прав доступа
    from database import is_business_owner, get_or_create_user
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этим бизнесом", show_alert=True)
            return

        business = await get_business_by_id(session, business_id)
        all_bookings = await get_business_bookings(session, business_id)

    from datetime import datetime, date as dt_date
    now = datetime.now()
    today = now.date()

    # Фильтруем записи по категориям
    upcoming = []  # Предстоящие (не сегодня)
    today_bookings = []  # Сегодня
    cancelled = []  # Отмененные
    completed = []  # Завершенные

    for booking in all_bookings:
        booking_datetime = datetime.combine(booking.booking_date, booking.booking_time)

        if booking.status == 'cancelled':
            cancelled.append(booking)
        elif booking.status == 'completed':
            completed.append(booking)
        elif booking.booking_date == today:
            today_bookings.append(booking)
        elif booking_datetime >= now:
            upcoming.append(booking)
        else:
            # Прошедшие, но не завершенные - считаем завершенными
            completed.append(booking)

    # Выбираем нужную категорию
    category_map = {
        "upcoming": ("📅 Предстоящие", upcoming),
        "today": ("🔥 Сегодня", today_bookings),
        "cancelled": ("❌ Отмененные", cancelled),
        "completed": ("✅ Завершенные", completed)
    }

    category_name, bookings = category_map.get(category, ("📅 Предстоящие", upcoming))

    # Пагинация
    per_page = 10
    total_pages = (len(bookings) + per_page - 1) // per_page if bookings else 1
    page = max(0, min(page, total_pages - 1))

    start_idx = page * per_page
    end_idx = start_idx + per_page
    page_bookings = bookings[start_idx:end_idx]

    # Формируем текст
    info_text = f"""
🏢 <b>{business.name}</b>
{category_name} записи

"""

    if not bookings:
        info_text += "Записей в этой категории нет"
    else:
        info_text += f"Показаны {start_idx + 1}-{min(end_idx, len(bookings))} из {len(bookings)}\n"

    # Создаем клавиатуру
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()

    # Кнопки категорий
    categories = [
        ("📅", "upcoming", len(upcoming)),
        ("🔥", "today", len(today_bookings)),
        ("❌", "cancelled", len(cancelled)),
        ("✅", "completed", len(completed))
    ]

    for emoji, cat, count in categories:
        btn_text = f"{emoji} {count}"
        if cat == category:
            btn_text = f"• {btn_text} •"
        builder.button(text=btn_text, callback_data=f"view_bookings:{business_id}:{cat}:0")

    builder.adjust(4)

    # Записи
    if page_bookings:
        for booking in page_bookings:
            status_emoji = {
                "pending": "⏳",
                "confirmed": "✅",
                "cancelled": "❌",
                "completed": "✔️"
            }.get(booking.status, "❓")

            builder.button(
                text=f"{status_emoji} {booking.booking_date.strftime('%d.%m')} {booking.booking_time.strftime('%H:%M')} - {booking.client.full_name[:20]}",
                callback_data=f"admin_booking_detail:{booking.id}"
            )

        builder.adjust(1)

    # Пагинация
    if total_pages > 1:
        pagination_buttons = []
        if page > 0:
            pagination_buttons.append(("◀️ Назад", f"view_bookings:{business_id}:{category}:{page-1}"))

        pagination_buttons.append((f"{page + 1}/{total_pages}", "noop"))

        if page < total_pages - 1:
            pagination_buttons.append(("Вперед ▶️", f"view_bookings:{business_id}:{category}:{page+1}"))

        for text, data in pagination_buttons:
            builder.button(text=text, callback_data=data)

        builder.adjust(len(pagination_buttons))

    # Навигация
    builder.button(text="◀️ Выбор бизнеса", callback_data="back_to_bookings_list")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(2)

    await callback.message.edit_text(
        info_text,
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("admin_booking_detail:"))
async def admin_booking_detail(callback: CallbackQuery):
    """Детальный просмотр записи с действиями"""
    booking_id = int(callback.data.split(":")[1])

    async with async_session_maker() as session:
        # Получаем запись со всеми связями
        result = await session.execute(
            select(Booking)
            .options(
                selectinload(Booking.client),
                selectinload(Booking.business),
                selectinload(Booking.service),
                selectinload(Booking.employee)
            )
            .where(Booking.id == booking_id)
        )
        booking = result.scalar_one_or_none()

        if not booking:
            await callback.answer("❌ Запись не найдена", show_alert=True)
            return

        # Проверка прав доступа
        from database import is_business_owner
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, booking.business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этой записью", show_alert=True)
            return

        # Получаем статистику клиента
        result = await session.execute(
            select(func.count(Booking.id))
            .where(Booking.client_id == booking.client_id)
            .where(Booking.business_id == booking.business_id)
        )
        total_bookings = result.scalar() or 0

        result = await session.execute(
            select(func.count(Booking.id))
            .where(Booking.client_id == booking.client_id)
            .where(Booking.business_id == booking.business_id)
            .where(Booking.status == "completed")
        )
        completed_bookings = result.scalar() or 0

    # Формируем сообщение
    status_emoji = {
        "pending": "⏳ Ожидает",
        "confirmed": "✅ Подтверждена",
        "completed": "✔️ Завершена",
        "cancelled": "❌ Отменена"
    }.get(booking.status, "❓ Неизвестно")

    info_text = f"""
📋 <b>Детали записи</b>

📅 Дата: {booking.booking_date.strftime('%d.%m.%Y')}
🕐 Время: {booking.booking_time.strftime('%H:%M')}
📊 Статус: {status_emoji}

🏢 {booking.business.name}
💼 Услуга: {booking.service.name}
⏱ Длительность: {booking.service.duration_minutes} мин
💰 Цена: {booking.service.price} ₽
"""

    if booking.employee:
        info_text += f"👔 Мастер: {booking.employee.name}\n"

    info_text += f"""
👤 <b>Клиент: {booking.client.full_name}</b>
"""

    if booking.client.phone:
        info_text += f"📱 Телефон: {booking.client.phone}\n"

    info_text += f"""
📈 Всего записей: {total_bookings}
✔️ Завершено: {completed_bookings}
"""

    if booking.notes:
        info_text += f"\n💬 Комментарий: {booking.notes}"

    # Формируем клавиатуру с действиями
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()

    if booking.status == "pending":
        builder.button(text="✅ Подтвердить", callback_data=f"admin_confirm_booking:{booking_id}")
        builder.button(text="❌ Отменить", callback_data=f"admin_cancel_booking:{booking_id}")
    elif booking.status == "confirmed":
        builder.button(text="✔️ Завершить", callback_data=f"admin_complete_booking:{booking_id}")
        builder.button(text="❌ Отменить", callback_data=f"admin_cancel_booking:{booking_id}")

    builder.button(text="📊 История клиента", callback_data=f"client_history:{booking.client_id}:{booking.business_id}")
    builder.button(text="◀️ Назад к записям", callback_data=f"view_bookings:{booking.business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await callback.message.edit_text(
        info_text,
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("admin_confirm_booking:"))
async def admin_confirm_booking(callback: CallbackQuery):
    """Подтверждение записи администратором"""
    booking_id = int(callback.data.split(":")[1])

    async with async_session_maker() as session:
        # Получаем запись
        result = await session.execute(
            select(Booking)
            .options(
                selectinload(Booking.business)
            )
            .where(Booking.id == booking_id)
        )
        booking = result.scalar_one_or_none()

        if not booking:
            await callback.answer("❌ Запись не найдена", show_alert=True)
            return

        # Проверка прав доступа
        from database import is_business_owner
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, booking.business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этой записью", show_alert=True)
            return

        if booking.status != "pending":
            await callback.answer("❌ Можно подтвердить только записи в статусе 'Ожидает'", show_alert=True)
            return

        # Подтверждаем запись
        booking.status = "confirmed"
        await session.commit()

    await callback.answer("✅ Запись подтверждена")
    # Перенаправляем обратно на детали записи
    await admin_booking_detail(callback)


@router.callback_query(F.data.startswith("admin_complete_booking:"))
async def admin_complete_booking(callback: CallbackQuery):
    """Завершение записи администратором"""
    booking_id = int(callback.data.split(":")[1])

    async with async_session_maker() as session:
        # Получаем запись
        result = await session.execute(
            select(Booking)
            .options(
                selectinload(Booking.business)
            )
            .where(Booking.id == booking_id)
        )
        booking = result.scalar_one_or_none()

        if not booking:
            await callback.answer("❌ Запись не найдена", show_alert=True)
            return

        # Проверка прав доступа
        from database import is_business_owner
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, booking.business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этой записью", show_alert=True)
            return

        if booking.status not in ["pending", "confirmed"]:
            await callback.answer("❌ Можно завершить только активные записи", show_alert=True)
            return

        # Завершаем запись
        booking.status = "completed"
        await session.commit()

    await callback.answer("✔️ Запись завершена")
    # Перенаправляем обратно на детали записи
    await admin_booking_detail(callback)


@router.callback_query(F.data.startswith("admin_cancel_booking:"))
async def admin_cancel_booking(callback: CallbackQuery):
    """Отмена записи администратором"""
    booking_id = int(callback.data.split(":")[1])

    async with async_session_maker() as session:
        # Получаем запись со всеми связями для уведомления
        result = await session.execute(
            select(Booking)
            .options(
                selectinload(Booking.client),
                selectinload(Booking.business),
                selectinload(Booking.service)
            )
            .where(Booking.id == booking_id)
        )
        booking = result.scalar_one_or_none()

        if not booking:
            await callback.answer("❌ Запись не найдена", show_alert=True)
            return

        # Проверка прав доступа
        from database import is_business_owner
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, booking.business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этой записью", show_alert=True)
            return

        if booking.status not in ["pending", "confirmed"]:
            await callback.answer("❌ Можно отменить только активные записи", show_alert=True)
            return

        # Отменяем запись
        booking.status = "cancelled"
        await session.commit()

        # Уведомляем клиента об отмене
        try:
            await callback.bot.send_message(
                chat_id=booking.client.telegram_id,
                text=f"""
❌ <b>Ваша запись отменена</b>

📅 Дата: {booking.booking_date.strftime('%d.%m.%Y')}
🕐 Время: {booking.booking_time.strftime('%H:%M')}
🏢 {booking.business.name}
💼 {booking.service.name}

Приносим извинения за неудобства.
""",
                parse_mode="HTML"
            )
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Error notifying client about cancellation: {e}")

    await callback.answer("❌ Запись отменена, клиент уведомлен")
    # Перенаправляем обратно на детали записи
    await admin_booking_detail(callback)


@router.callback_query(F.data.startswith("client_history:"))
async def view_client_history(callback: CallbackQuery):
    """Просмотр полной истории клиента в бизнесе"""
    parts = callback.data.split(":")
    client_id = int(parts[1])
    business_id = int(parts[2])

    async with async_session_maker() as session:
        # Проверка прав доступа
        from database import is_business_owner
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, business_id, user.id):
            await callback.answer("❌ У вас нет прав для просмотра этой информации", show_alert=True)
            return

        # Получаем клиента
        from database import User
        result = await session.execute(
            select(User).where(User.id == client_id)
        )
        client = result.scalar_one_or_none()

        if not client:
            await callback.answer("❌ Клиент не найден", show_alert=True)
            return

        # Получаем бизнес
        business = await get_business_by_id(session, business_id)

        # Получаем все записи клиента в этом бизнесе
        from database import Service
        result = await session.execute(
            select(Booking)
            .options(
                selectinload(Booking.service),
                selectinload(Booking.employee)
            )
            .where(Booking.client_id == client_id)
            .where(Booking.business_id == business_id)
            .order_by(Booking.booking_date.desc(), Booking.booking_time.desc())
        )
        all_bookings = result.scalars().all()

        # Статистика
        total_bookings = len(all_bookings)
        completed = len([b for b in all_bookings if b.status == "completed"])
        cancelled = len([b for b in all_bookings if b.status == "cancelled"])
        pending = len([b for b in all_bookings if b.status in ["pending", "confirmed"]])

        # Общая сумма (только завершенные)
        total_spent = sum(b.service.price for b in all_bookings if b.status == "completed")

        # Первый визит
        first_booking = all_bookings[-1] if all_bookings else None

        # Последний завершенный визит
        completed_bookings = [b for b in all_bookings if b.status == "completed"]
        last_visit = completed_bookings[0] if completed_bookings else None

        # Любимые услуги (топ 3)
        from collections import Counter
        service_counts = Counter()
        for booking in all_bookings:
            if booking.status == "completed":
                service_counts[booking.service.name] += 1

        top_services = service_counts.most_common(3)

    # Формируем сообщение
    info_text = f"""
👤 <b>История клиента</b>

<b>{client.full_name}</b>
"""

    if client.phone:
        info_text += f"📱 {client.phone}\n"

    info_text += f"""
🏢 Бизнес: {business.name}

📊 <b>Статистика:</b>
📈 Всего записей: {total_bookings}
✔️ Завершено: {completed}
❌ Отменено: {cancelled}
⏳ Активных: {pending}
💰 Потрачено: {total_spent} ₽
"""

    if first_booking:
        info_text += f"\n🎯 Первый визит: {first_booking.booking_date.strftime('%d.%m.%Y')}"

    if last_visit:
        info_text += f"\n🕐 Последний визит: {last_visit.booking_date.strftime('%d.%m.%Y')}"

    # Любимые услуги
    if top_services:
        info_text += "\n\n⭐ <b>Любимые услуги:</b>\n"
        for i, (service_name, count) in enumerate(top_services, 1):
            info_text += f"{i}. {service_name} ({count} раз)\n"

    # Последние визиты
    if all_bookings:
        info_text += "\n📅 <b>Последние записи:</b>\n"
        for booking in all_bookings[:5]:
            status_emoji = {
                "pending": "⏳",
                "confirmed": "✅",
                "completed": "✔️",
                "cancelled": "❌"
            }.get(booking.status, "❓")

            date_str = booking.booking_date.strftime('%d.%m.%Y')
            time_str = booking.booking_time.strftime('%H:%M')

            info_text += f"{status_emoji} {date_str} {time_str} - {booking.service.name}"
            if booking.employee:
                info_text += f" ({booking.employee.name})"
            info_text += "\n"

    # Клавиатура
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()

    builder.button(text="◀️ Назад", callback_data=f"view_bookings:{business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)

    await callback.message.edit_text(
        info_text,
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )
    await callback.answer()


# ===== РЕДАКТИРОВАНИЕ БИЗНЕСА =====

@router.callback_query(F.data.startswith("edit_business:"))
async def start_business_edit(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования бизнеса"""
    business_id = int(callback.data.split(":")[1])

    # Проверка прав доступа
    from database import is_business_owner, get_or_create_user
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            callback.from_user.id,
            callback.from_user.username,
            callback.from_user.full_name
        )
        if not await is_business_owner(session, business_id, user.id):
            await callback.answer("❌ У вас нет прав для управления этим бизнесом", show_alert=True)
            return

        business = await get_business_by_id(session, business_id)

    await state.update_data(business_id=business_id)
    
    info_text = f"""
✏️ <b>Редактирование: {business.name}</b>

Выберите поле для редактирования:
"""
    
    await callback.message.edit_text(
        info_text,
        parse_mode="HTML",
        reply_markup=admin_kb.get_business_edit_keyboard(business_id)
    )
    await state.set_state(BusinessEditStates.choosing_field)
    await callback.answer()


@router.callback_query(F.data.startswith("edit_field:name:"), BusinessEditStates.choosing_field)
async def edit_name_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования названия"""
    business_id = int(callback.data.split(":")[2])
    await state.update_data(business_id=business_id)
    
    await callback.message.edit_text("Введите новое название бизнеса:")
    await state.set_state(BusinessEditStates.editing_name)
    await callback.answer()


@router.message(BusinessEditStates.editing_name)
async def edit_name_save(message: Message, state: FSMContext):
    """Сохранение нового названия"""
    data = await state.get_data()
    business_id = data['business_id']

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        business.name = message.text
        await session.commit()
        await session.refresh(business)

    info_text = f"""
✏️ <b>Редактирование: {message.text}</b>

✅ Название успешно изменено на: <b>{message.text}</b>

Выберите поле для редактирования:
"""

    await message.answer(
        info_text,
        parse_mode="HTML",
        reply_markup=admin_kb.get_business_edit_keyboard(business_id)
    )
    await state.set_state(BusinessEditStates.choosing_field)


@router.callback_query(F.data.startswith("edit_field:description:"), BusinessEditStates.choosing_field)
async def edit_description_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования описания"""
    business_id = int(callback.data.split(":")[2])
    await state.update_data(business_id=business_id)
    
    await callback.message.edit_text("Введите новое описание (или '-' для удаления):")
    await state.set_state(BusinessEditStates.editing_description)
    await callback.answer()


@router.message(BusinessEditStates.editing_description)
async def edit_description_save(message: Message, state: FSMContext):
    """Сохранение нового описания"""
    data = await state.get_data()
    business_id = data['business_id']

    description = None if message.text == "-" else message.text

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        business.description = description
        await session.commit()
        await session.refresh(business)

        business_name = business.name

    description_display = description if description else "(удалено)"

    info_text = f"""
✏️ <b>Редактирование: {business_name}</b>

✅ Описание успешно обновлено!
📄 Новое описание: <i>{description_display}</i>

Выберите поле для редактирования:
"""

    await message.answer(
        info_text,
        parse_mode="HTML",
        reply_markup=admin_kb.get_business_edit_keyboard(business_id)
    )
    await state.set_state(BusinessEditStates.choosing_field)


@router.callback_query(F.data.startswith("edit_field:address:"), BusinessEditStates.choosing_field)
async def edit_address_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования адреса"""
    business_id = int(callback.data.split(":")[2])
    await state.update_data(business_id=business_id)
    
    await callback.message.edit_text("Введите новый адрес (или '-' для удаления):")
    await state.set_state(BusinessEditStates.editing_address)
    await callback.answer()


@router.message(BusinessEditStates.editing_address)
async def edit_address_save(message: Message, state: FSMContext):
    """Сохранение нового адреса"""
    data = await state.get_data()
    business_id = data['business_id']

    address = None if message.text == "-" else message.text

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        business.address = address
        await session.commit()
        await session.refresh(business)

        business_name = business.name

    address_display = address if address else "(удалён)"

    info_text = f"""
✏️ <b>Редактирование: {business_name}</b>

✅ Адрес успешно обновлен!
📍 Новый адрес: <i>{address_display}</i>

Выберите поле для редактирования:
"""

    await message.answer(
        info_text,
        parse_mode="HTML",
        reply_markup=admin_kb.get_business_edit_keyboard(business_id)
    )
    await state.set_state(BusinessEditStates.choosing_field)


@router.callback_query(F.data.startswith("edit_field:phone:"), BusinessEditStates.choosing_field)
async def edit_phone_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования телефона"""
    from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove

    business_id = int(callback.data.split(":")[2])
    await state.update_data(business_id=business_id)

    # Создаём клавиатуру с кнопкой отправки контакта
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📱 Отправить контакт", request_contact=True)],
            [KeyboardButton(text="❌ Отмена")]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
        input_field_placeholder="+79991234567"
    )

    await callback.message.edit_text("Введите новый телефон вручную или используйте кнопку ниже:")
    await callback.message.answer(
        "Вы можете:\n• Отправить свой контакт кнопкой\n• Ввести номер вручную (например: +79991234567)\n• Написать '-' для удаления телефона",
        reply_markup=keyboard
    )
    await state.set_state(BusinessEditStates.editing_phone)
    await callback.answer()


@router.message(BusinessEditStates.editing_phone)
async def edit_phone_save(message: Message, state: FSMContext):
    """Сохранение нового телефона"""
    from bot.utils.validators import validate_phone
    from aiogram.types import ReplyKeyboardRemove

    data = await state.get_data()
    business_id = data['business_id']

    # Обработка отмены
    if message.text == "❌ Отмена":
        async with async_session_maker() as session:
            business = await get_business_by_id(session, business_id)
            business_name = business.name

        info_text = f"""
✏️ <b>Редактирование: {business_name}</b>

❌ Изменение телефона отменено

Выберите поле для редактирования:
"""
        await message.answer(
            info_text,
            parse_mode="HTML",
            reply_markup=ReplyKeyboardRemove()
        )
        await message.answer(
            "Выберите действие:",
            reply_markup=admin_kb.get_business_edit_keyboard(business_id)
        )
        await state.set_state(BusinessEditStates.choosing_field)
        return

    phone = None

    # Обработка контакта (если пользователь отправил свой контакт)
    if message.contact:
        phone = message.contact.phone_number
        if not phone.startswith('+'):
            phone = '+' + phone
    elif message.text != "-":
        if not validate_phone(message.text):
            await message.answer(
                "❌ Неверный формат телефона!\n"
                "Используйте формат: +7XXXXXXXXXX или 8XXXXXXXXXX\n\n"
                "Попробуйте снова или '-' чтобы очистить:"
            )
            return
        phone = message.text

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        business.phone = phone
        await session.commit()
        await session.refresh(business)

        business_name = business.name

    phone_display = phone if phone else "(удалён)"

    info_text = f"""
✏️ <b>Редактирование: {business_name}</b>

✅ Телефон успешно обновлен!
📞 Новый телефон: <code>{phone_display}</code>

Выберите поле для редактирования:
"""

    # Убираем reply клавиатуру и показываем inline клавиатуру
    await message.answer(
        info_text,
        parse_mode="HTML",
        reply_markup=ReplyKeyboardRemove()
    )
    await message.answer(
        "Выберите действие:",
        reply_markup=admin_kb.get_business_edit_keyboard(business_id)
    )
    await state.set_state(BusinessEditStates.choosing_field)


@router.callback_query(F.data.startswith("edit_field:hours:"), BusinessEditStates.choosing_field)
async def edit_hours_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования времени работы"""
    business_id = int(callback.data.split(":")[2])
    await state.update_data(business_id=business_id)

    # Добавляем inline кнопку отмены
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="❌ Отменить", callback_data=f"cancel_edit:{business_id}")
    builder.adjust(1)

    await callback.message.edit_text(
        "Введите новое время работы в формате:\n"
        "<b>09:00-18:00</b>\n\n"
        "Или '-' для удаления:",
        reply_markup=builder.as_markup(),
        parse_mode="HTML"
    )
    await state.set_state(BusinessEditStates.editing_working_hours)
    await callback.answer()


@router.callback_query(F.data.startswith("cancel_edit:"))
async def cancel_edit_field(callback: CallbackQuery, state: FSMContext):
    """Отмена редактирования поля"""
    business_id = int(callback.data.split(":")[1])

    await state.clear()

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)

    await callback.message.edit_text(
        f"❌ Редактирование отменено.\n\n"
        f"Выберите поле для редактирования:",
        reply_markup=admin_kb.get_business_edit_keyboard(business_id)
    )
    await state.set_state(BusinessEditStates.choosing_field)
    await callback.answer()


@router.message(BusinessEditStates.editing_working_hours)
async def edit_hours_save(message: Message, state: FSMContext):
    """Сохранение нового времени работы"""
    from datetime import time

    data = await state.get_data()
    business_id = data['business_id']

    working_hours_start = None
    working_hours_end = None

    if message.text != "-":
        try:
            times = message.text.split("-")
            if len(times) == 2:
                # Заменяем точки на двоеточия для поддержки формата "9.30-18.00"
                start_time = times[0].strip().replace(".", ":")
                end_time = times[1].strip().replace(".", ":")

                start_hour, start_min = map(int, start_time.split(":"))
                end_hour, end_min = map(int, end_time.split(":"))
                working_hours_start = time(start_hour, start_min)
                working_hours_end = time(end_hour, end_min)
        except (ValueError, IndexError):
            await message.answer(
                "❌ Неверный формат времени!\n"
                "Используйте формат: 09:00-18:00 или 9.30-18.00"
            )
            return

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        business.working_hours_start = working_hours_start
        business.working_hours_end = working_hours_end
        await session.commit()
        await session.refresh(business)

        business_name = business.name

    time_display = f"{working_hours_start.strftime('%H:%M')}-{working_hours_end.strftime('%H:%M')}" if working_hours_start else "(не указано)"

    info_text = f"""
✏️ <b>Редактирование: {business_name}</b>

✅ Время работы успешно обновлено!
⏰ Новое время: <b>{time_display}</b>

Выберите поле для редактирования:
"""

    await message.answer(
        info_text,
        parse_mode="HTML",
        reply_markup=admin_kb.get_business_edit_keyboard(business_id)
    )
    await state.set_state(BusinessEditStates.choosing_field)


@router.callback_query(F.data.startswith("edit_field:break:"), BusinessEditStates.choosing_field)
async def edit_break_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования перерыва"""
    business_id = int(callback.data.split(":")[2])
    await state.update_data(business_id=business_id)

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        current_break = "(не указан)"
        if business.break_start and business.break_end:
            current_break = f"{business.break_start.strftime('%H:%M')}-{business.break_end.strftime('%H:%M')}"

    await callback.message.edit_text(
        f"☕ <b>Текущий перерыв:</b> {current_break}\n\n"
        "Введите новое время перерыва в формате:\n"
        "<b>13:00-14:00</b> или <b>13.00-14.00</b>\n\n"
        "Или '-' для удаления перерыва:",
        parse_mode="HTML"
    )
    await state.set_state(BusinessEditStates.editing_break)
    await callback.answer()


@router.message(BusinessEditStates.editing_break)
async def edit_break_save(message: Message, state: FSMContext):
    """Сохранение нового времени перерыва"""
    from datetime import time

    data = await state.get_data()
    business_id = data['business_id']

    break_start = None
    break_end = None

    if message.text != "-":
        try:
            times = message.text.split("-")
            if len(times) == 2:
                # Заменяем точки на двоеточия
                start_time = times[0].strip().replace(".", ":")
                end_time = times[1].strip().replace(".", ":")

                start_hour, start_min = map(int, start_time.split(":"))
                end_hour, end_min = map(int, end_time.split(":"))
                break_start = time(start_hour, start_min)
                break_end = time(end_hour, end_min)
        except (ValueError, IndexError):
            await message.answer(
                "❌ Неверный формат времени!\n"
                "Используйте формат: 13:00-14:00 или 13.00-14.00"
            )
            return

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        business.break_start = break_start
        business.break_end = break_end
        await session.commit()
        await session.refresh(business)

        business_name = business.name

    break_display = f"{break_start.strftime('%H:%M')}-{break_end.strftime('%H:%M')}" if break_start else "(не указан)"

    info_text = f"""
✏️ <b>Редактирование: {business_name}</b>

✅ Перерыв успешно обновлен!
☕ Новый перерыв: <b>{break_display}</b>

Выберите поле для редактирования:
"""

    await message.answer(
        info_text,
        parse_mode="HTML",
        reply_markup=admin_kb.get_business_edit_keyboard(business_id)
    )
    await state.set_state(BusinessEditStates.choosing_field)


@router.callback_query(F.data.startswith("edit_field:photos:"), BusinessEditStates.choosing_field)
async def edit_photos_start(callback: CallbackQuery, state: FSMContext):
    """Начало управления фотографиями"""
    import json

    business_id = int(callback.data.split(":")[2])
    await state.update_data(business_id=business_id)

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        photos = json.loads(business.photos) if business.photos else []
        business_name = business.name

    # Отправляем текущие фото если есть
    if photos:
        await callback.message.answer(f"📷 <b>Текущие фотографии {business_name}:</b>", parse_mode="HTML")
        for photo_id in photos:
            try:
                await callback.message.answer_photo(photo_id)
            except:
                pass

    has_photos = len(photos) > 0

    await callback.message.answer(
        f"📷 <b>Управление фотографиями: {business_name}</b>\n\n"
        f"Фотографий: {len(photos)}\n\n"
        "Выберите действие:",
        parse_mode="HTML",
        reply_markup=admin_kb.get_photos_management_keyboard(business_id, has_photos)
    )
    await state.set_state(BusinessEditStates.editing_photos)
    await callback.answer()


@router.callback_query(F.data.startswith("add_photo:"), BusinessEditStates.editing_photos)
async def add_photo_prompt(callback: CallbackQuery, state: FSMContext):
    """Запрос на добавление фото"""
    business_id = int(callback.data.split(":")[1])
    await state.update_data(business_id=business_id)

    await callback.message.edit_text(
        "📷 Отправьте фотографию бизнеса:\n\n"
        "Отправьте фото или '-' для отмены",
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(BusinessEditStates.editing_photos, F.photo)
async def photo_received(message: Message, state: FSMContext):
    """Получение и сохранение фото"""
    import json

    data = await state.get_data()
    business_id = data['business_id']

    # Получаем file_id самого большого фото
    photo_file_id = message.photo[-1].file_id

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        photos = json.loads(business.photos) if business.photos else []
        photos.append(photo_file_id)
        business.photos = json.dumps(photos)
        await session.commit()
        await session.refresh(business)
        business_name = business.name

    await message.answer(
        f"✅ Фотография добавлена!\n\n"
        f"Всего фотографий: {len(photos)}",
        parse_mode="HTML",
        reply_markup=admin_kb.get_photos_management_keyboard(business_id, True)
    )


@router.callback_query(F.data.startswith("delete_all_photos:"), BusinessEditStates.editing_photos)
async def delete_all_photos(callback: CallbackQuery, state: FSMContext):
    """Удаление всех фотографий"""
    business_id = int(callback.data.split(":")[1])

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        business.photos = None
        await session.commit()
        business_name = business.name

    await callback.message.edit_text(
        f"✅ Все фотографии удалены!",
        parse_mode="HTML",
        reply_markup=admin_kb.get_photos_management_keyboard(business_id, False)
    )
    await callback.answer()


@router.callback_query(F.data.startswith("back_to_edit:"), BusinessEditStates.editing_photos)
async def back_to_edit_from_photos(callback: CallbackQuery, state: FSMContext):
    """Возврат к редактированию бизнеса"""
    business_id = int(callback.data.split(":")[1])

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        business_name = business.name

    await callback.message.edit_text(
        f"✏️ <b>Редактирование: {business_name}</b>\n\n"
        "Выберите поле для редактирования:",
        parse_mode="HTML",
        reply_markup=admin_kb.get_business_edit_keyboard(business_id)
    )
    await state.set_state(BusinessEditStates.choosing_field)
    await callback.answer()


@router.callback_query(F.data.startswith("edit_field:directions:"), BusinessEditStates.choosing_field)
async def edit_directions_start(callback: CallbackQuery, state: FSMContext):
    """Начало редактирования инструкций как добраться"""
    business_id = int(callback.data.split(":")[2])
    await state.update_data(business_id=business_id)

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        current_directions = business.directions or "(не указано)"

    await callback.message.edit_text(
        f"🗺 <b>Текущие инструкции:</b>\n{current_directions}\n\n"
        "Введите новые инструкции как добраться:\n\n"
        "Или '-' для удаления:",
        parse_mode="HTML"
    )
    await state.set_state(BusinessEditStates.editing_directions)
    await callback.answer()


@router.message(BusinessEditStates.editing_directions)
async def edit_directions_save(message: Message, state: FSMContext):
    """Сохранение инструкций как добраться"""
    data = await state.get_data()
    business_id = data['business_id']

    directions = None if message.text == "-" else message.text

    async with async_session_maker() as session:
        business = await get_business_by_id(session, business_id)
        business.directions = directions
        await session.commit()
        await session.refresh(business)
        business_name = business.name

    directions_display = directions if directions else "(не указано)"

    info_text = f"""
✏️ <b>Редактирование: {business_name}</b>

✅ Инструкции успешно обновлены!
🗺 Как добраться:
{directions_display}

Выберите поле для редактирования:
"""

    await message.answer(
        info_text,
        parse_mode="HTML",
        reply_markup=admin_kb.get_business_edit_keyboard(business_id)
    )
    await state.set_state(BusinessEditStates.choosing_field)


# ===== ВОЗВРАТ В ГЛАВНОЕ МЕНЮ =====

@router.callback_query(F.data == "main_menu")
async def back_to_main_menu(callback: CallbackQuery, state: FSMContext):
    """Возврат в главное меню"""
    await state.clear()

    # Получаем роли для клавиатуры
    async with async_session_maker() as session:
        employee = await get_employee_by_telegram_id(session, callback.from_user.id)

    # Удаляем предыдущее сообщение
    try:
        await callback.message.delete()
    except:
        pass

    # Отправляем новое сообщение с главным меню админа
    await callback.bot.send_message(
        chat_id=callback.from_user.id,
        text="🏢 Панель администратора\n\nЗдесь вы можете управлять своими бизнесами, услугами, сотрудниками и просматривать записи клиентов.",
        reply_markup=admin_kb.get_admin_menu_keyboard(show_master_button=(employee is not None), is_super_admin=(callback.from_user.id == 437862772))
    )
    await callback.answer()
