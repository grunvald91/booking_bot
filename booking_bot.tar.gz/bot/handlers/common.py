"""
Обработчики общих команд (/start, /help и т.д.)
"""
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.fsm.context import FSMContext

from database import async_session_maker
from database.crud import get_or_create_user, get_user_businesses, get_employee_by_telegram_id
from bot.keyboards.client_kb import get_main_menu_keyboard
from bot.keyboards.admin_kb import get_admin_menu_keyboard
from bot.keyboards import master_kb
from bot.config import ADMIN_IDS

router = Router()


@router.message(Command("start"))
async def cmd_start(message: Message, state: FSMContext):
    """Обработка команды /start"""
    # Очищаем состояние FSM при старте
    await state.clear()

    async with async_session_maker() as session:
        # Создаем или получаем пользователя
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name
        )

        # Проверяем, является ли пользователь владельцем бизнеса
        businesses = await get_user_businesses(session, user.id)

        # Проверяем, является ли пользователь мастером
        employee = await get_employee_by_telegram_id(session, message.from_user.id)

    # Проверяем, является ли пользователь администратором
    is_admin = message.from_user.id in ADMIN_IDS

    welcome_text = f"""
Привет, {message.from_user.first_name}! 👋

Я бот для онлайн-записи на услуги.

Здесь вы можете:
📅 Записаться к специалистам
📋 Управлять своими записями
"""

    # Приоритет: Админ/Владелец > Мастер > Клиент
    if is_admin or businesses:
        if businesses:
            welcome_text += f"\n🏢 У вас {len(businesses)} бизнес(-ов)"
        else:
            welcome_text += "\n🏢 Вы можете создать свой бизнес"

        # Сохраняем текущий режим
        await state.update_data(current_mode="admin")

        await message.answer(
            welcome_text,
            reply_markup=get_admin_menu_keyboard(show_master_button=(employee is not None), is_super_admin=(message.from_user.id == 437862772))
        )
    elif employee:
        welcome_text += f"\n👨‍💼 Вы мастер в {employee.business.name}"

        # Сохраняем текущий режим
        await state.update_data(current_mode="master")

        await message.answer(
            welcome_text,
            reply_markup=master_kb.get_master_menu_keyboard(show_admin_button=(is_admin or len(businesses) > 0))
        )
    else:
        # Сохраняем текущий режим
        await state.update_data(current_mode="client")

        await message.answer(
            welcome_text,
            reply_markup=get_main_menu_keyboard(show_admin_button=(is_admin or len(businesses) > 0), show_master_button=(employee is not None))
        )


@router.message(Command("help"))
@router.message(F.text == "ℹ️ Помощь")
async def cmd_help(message: Message, state: FSMContext):
    """Обработка команды /help с контекстной справкой для каждого режима"""

    # Получаем роли пользователя
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name
        )
        businesses = await get_user_businesses(session, user.id)
        employee = await get_employee_by_telegram_id(session, message.from_user.id)

    is_admin = message.from_user.id in ADMIN_IDS
    show_admin = is_admin or len(businesses) > 0
    show_master = employee is not None
    is_super_admin = message.from_user.id == 437862772

    # Получаем текущий режим из состояния
    state_data = await state.get_data()
    current_mode = state_data.get("current_mode", "client")

    # Справка для режима клиента
    client_help = f"""
📖 <b>Помощь: Режим клиента</b>

<b>Основные функции:</b>
📅 <b>Записаться</b> - создать новую запись на услугу
   • Выберите бизнес из списка
   • Выберите нужную услугу
   • Выберите мастера (или "Любой мастер")
   • Выберите удобную дату и время
   • Подтвердите запись

🔄 <b>Повторить запись</b> - быстро повторить предыдущую запись
   • Выберите из истории записей
   • Измените только дату и время

📋 <b>Мои записи</b> - посмотреть и управлять записями
   • Просмотр предстоящих записей
   • Отмена записи при необходимости

<b>Команды:</b>
/start - Перезапустить бота
/help - Показать эту справку
/cancel - Отменить текущее действие

<b>Ваш Telegram ID:</b> <code>{message.from_user.id}</code>
"""

    # Справка для режима администратора
    admin_help = f"""
📖 <b>Помощь: Режим администратора</b>

<b>Управление бизнесом:</b>
🏢 <b>Мои бизнесы</b> - список всех ваших бизнесов
   • Редактирование информации о бизнесе
   • Управление услугами и сотрудниками
   • Включение/выключение бизнеса

➕ <b>Добавить бизнес</b> - создать новый бизнес
   • Выберите тип бизнеса
   • Укажите название и описание
   • Добавьте адрес и контакты
   • Настройте время работы

<b>Управление услугами:</b>
   • Добавляйте услуги через меню бизнеса
   • Укажите название, длительность и цену
   • Включайте/выключайте услуги

<b>Управление сотрудниками:</b>
   • Добавляйте мастеров через меню бизнеса
   • Укажите имя и специализацию
   • Добавьте Telegram ID для доступа к панели мастера
   • Настройте интервал записи

📊 <b>Записи</b> - просмотр всех записей клиентов
   • Фильтрация по датам
   • Подтверждение, завершение, отмена записей

<b>Команды:</b>
/start - Перезапустить бота
/help - Показать эту справку
/cancel - Отменить текущее действие

<b>Ваш Telegram ID:</b> <code>{message.from_user.id}</code>
"""

    # Справка для режима мастера
    master_help = f"""
📖 <b>Помощь: Режим мастера</b>

<b>Ваше расписание:</b>
📅 <b>Моё расписание</b> - просмотр записей
   • Записи на сегодня, завтра, неделю
   • Информация о клиентах
   • Завершение и отмена записей

<b>Работа с клиентами:</b>
➕ <b>Записать клиента</b> - ручная запись
   • Выберите услугу
   • Введите имя и телефон клиента
   • Выберите дату и время
   • Подтвердите запись

👤 <b>История клиента</b> - при просмотре записи
   • Посмотреть предыдущие записи клиента
   • Информация о посещениях

📊 <b>Моя статистика</b> - показатели работы
   • Количество записей
   • Выручка за период

<b>Статусы записей:</b>
⏳ Ожидает подтверждения
✅ Подтверждена
✔️ Завершена
❌ Отменена

<b>Команды:</b>
/start - Перезапустить бота
/help - Показать эту справку
/cancel - Отменить текущее действие

<b>Ваш Telegram ID:</b> <code>{message.from_user.id}</code>
"""

    # Выбираем справку и клавиатуру в зависимости от режима
    if current_mode == "admin":
        help_text = admin_help
        # Добавляем информацию для супер-админа
        if is_super_admin:
            help_text += """
<b>Супер-админ:</b>
👥 <b>Управление администраторами</b>
   • Добавление новых администраторов
   • Удаление администраторов
"""
        reply_keyboard = get_admin_menu_keyboard(show_master_button=show_master, is_super_admin=is_super_admin)
    elif current_mode == "master":
        help_text = master_help
        reply_keyboard = master_kb.get_master_menu_keyboard(show_admin_button=show_admin)
    else:
        help_text = client_help
        reply_keyboard = get_main_menu_keyboard(show_admin_button=show_admin, show_master_button=show_master)

    await message.answer(help_text, parse_mode="HTML", reply_markup=reply_keyboard)


@router.message(Command("cancel"))
@router.message(F.text.in_(["❌ Отмена", "Отмена"]))
async def cmd_cancel(message: Message, state: FSMContext):
    """Отмена текущего действия"""
    current_state = await state.get_state()

    # Получаем роли пользователя для кнопок переключения
    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name
        )
        businesses = await get_user_businesses(session, user.id)
        employee = await get_employee_by_telegram_id(session, message.from_user.id)

    is_admin = message.from_user.id in ADMIN_IDS
    show_admin = is_admin or len(businesses) > 0
    show_master = employee is not None

    reply_keyboard = get_main_menu_keyboard(show_admin_button=show_admin, show_master_button=show_master)

    if current_state is None:
        await message.answer(
            "Нечего отменять.",
            reply_markup=reply_keyboard
        )
        return

    await state.clear()
    await message.answer(
        "Действие отменено.",
        reply_markup=reply_keyboard
    )


@router.message(F.text == "👤 Режим клиента")
async def switch_to_client_mode(message: Message, state: FSMContext):
    """Переключение в режим клиента"""
    async with async_session_maker() as session:
        # Проверяем роли пользователя
        is_admin = message.from_user.id in ADMIN_IDS
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name
        )
        businesses = await get_user_businesses(session, user.id)
        employee = await get_employee_by_telegram_id(session, message.from_user.id)

    # Показываем кнопки админа/мастера если есть доступ
    show_admin = is_admin or len(businesses) > 0
    show_master = employee is not None

    # Сохраняем текущий режим
    await state.update_data(current_mode="client")

    await message.answer(
        "🔄 Переключено в режим клиента",
        reply_markup=get_main_menu_keyboard(show_admin_button=show_admin, show_master_button=show_master)
    )


@router.message(F.text == "🏢 Режим администратора")
async def switch_to_admin_mode(message: Message, state: FSMContext):
    """Переключение в режим администратора"""
    # Проверяем, является ли пользователь администратором
    is_admin = message.from_user.id in ADMIN_IDS

    async with async_session_maker() as session:
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name
        )
        businesses = await get_user_businesses(session, user.id)
        employee = await get_employee_by_telegram_id(session, message.from_user.id)

    # Разрешаем доступ если есть бизнесы ИЛИ пользователь в ADMIN_IDS
    if not businesses and not is_admin:
        await message.answer(
            "У вас нет доступа к панели администратора.",
            reply_markup=get_main_menu_keyboard(show_admin_button=False, show_master_button=(employee is not None))
        )
        return

    # Сохраняем текущий режим
    await state.update_data(current_mode="admin")

    await message.answer(
        "🔄 Переключено в режим администратора",
        reply_markup=get_admin_menu_keyboard(show_master_button=(employee is not None), is_super_admin=(message.from_user.id == 437862772))
    )


@router.message(F.text.in_(["👤 Режим мастера", "👨‍💼 Режим мастера"]))
async def switch_to_master_mode(message: Message, state: FSMContext):
    """Переключение в режим мастера"""
    async with async_session_maker() as session:
        employee = await get_employee_by_telegram_id(session, message.from_user.id)
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name
        )
        businesses = await get_user_businesses(session, user.id)

    if not employee:
        is_admin = message.from_user.id in ADMIN_IDS
        show_admin = is_admin or len(businesses) > 0
        await message.answer(
            "❌ Вы не зарегистрированы как мастер.\n\n"
            "Обратитесь к администратору бизнеса, чтобы он добавил ваш Telegram ID в профиль сотрудника.",
            reply_markup=get_main_menu_keyboard(show_admin_button=show_admin, show_master_button=False)
        )
        return

    is_admin = message.from_user.id in ADMIN_IDS

    # Сохраняем текущий режим
    await state.update_data(current_mode="master")

    await message.answer(
        f"👋 Добро пожаловать, {employee.name}!\n\n"
        f"🏢 Бизнес: {employee.business.name}\n"
        f"💼 Специализация: {employee.specialization or 'Не указана'}\n\n"
        f"Выберите действие:",
        reply_markup=master_kb.get_master_menu_keyboard(show_admin_button=(is_admin or len(businesses) > 0))
    )
