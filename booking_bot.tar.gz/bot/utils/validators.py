"""
Функции валидации входных данных
"""
import re


def validate_phone(phone: str) -> bool:
    """Проверка формата номера телефона"""
    # Допустимые форматы: +7XXXXXXXXXX, 8XXXXXXXXXX, 7XXXXXXXXXX
    clean_phone = re.sub(r'[\s\-\(\)]', '', phone)

    if clean_phone.startswith('+'):
        clean_phone = clean_phone[1:]

    # Должно быть 10-11 цифр
    if not clean_phone.isdigit():
        return False

    if len(clean_phone) not in [10, 11]:
        return False

    # Если 11 цифр, должно начинаться с 7 или 8
    if len(clean_phone) == 11 and clean_phone[0] not in ['7', '8']:
        return False

    return True


def validate_duration(duration_str: str) -> tuple[bool, int]:
    """
    Проверка длительности услуги
    Возвращает (валидно, значение)
    """
    try:
        duration = int(duration_str)
        if duration <= 0 or duration > 480:  # Макс 8 часов
            return False, 0
        return True, duration
    except ValueError:
        return False, 0


def validate_price(price_str: str) -> tuple[bool, float]:
    """
    Проверка цены услуги
    Возвращает (валидно, значение)
    """
    try:
        price = float(price_str)
        if price < 0 or price > 1000000:  # Макс 1 млн
            return False, 0.0
        return True, price
    except ValueError:
        return False, 0.0


def safe_split_callback(callback_data: str, expected_parts: int = 2) -> list[str] | None:
    """
    Безопасный парсинг callback_data
    Возвращает список частей или None если формат неверный
    """
    parts = callback_data.split(":")
    if len(parts) != expected_parts:
        return None
    return parts
