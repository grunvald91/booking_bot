"""
Типы бизнесов и их отображение
"""

BUSINESS_TYPES = {
    "salon": "Салон красоты",
    "psychologist": "Психолог",
    "auto_service": "Автосервис",
    "tire_service": "Шиномонтаж",
    "spa": "Массаж/СПА",
    "medical": "Медицинская клиника",
    "education": "Обучение",
    "other": "Другое",
}


def get_business_type_name(type_code: str) -> str:
    """Получить читаемое название типа бизнеса"""
    return BUSINESS_TYPES.get(type_code, type_code)
