"""
Клавиатуры для клиентской части бота
"""
from typing import List, Union
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database.models import Business, Service, Employee
from bot.utils.business_types import get_business_type_name


def get_mode_switch_keyboard(show_admin_button: bool = False, show_master_button: bool = False, show_client_button: bool = False) -> ReplyKeyboardMarkup:
    """Минимальная клавиатура только с кнопками переключения режима"""
    mode_buttons = []

    if show_client_button:
        mode_buttons.append([KeyboardButton(text="👤 Режим клиента")])
    if show_admin_button:
        mode_buttons.append([KeyboardButton(text="🏢 Режим администратора")])
    if show_master_button:
        mode_buttons.append([KeyboardButton(text="👨‍💼 Режим мастера")])

    # Если нет кнопок переключения, создаем минимальную клавиатуру
    if not mode_buttons:
        mode_buttons = [[KeyboardButton(text="🏠 Главное меню")]]

    keyboard = ReplyKeyboardMarkup(
        keyboard=mode_buttons,
        resize_keyboard=True
    )
    return keyboard


def get_main_menu_keyboard(show_admin_button: bool = False, show_master_button: bool = False) -> ReplyKeyboardMarkup:
    """Главное меню для клиента"""
    buttons = [
        [KeyboardButton(text="📅 Записаться"), KeyboardButton(text="🔄 Повторить запись")],
        [KeyboardButton(text="📋 Мои записи")],
        [KeyboardButton(text="ℹ️ Помощь")],
    ]

    # Добавляем кнопки переключения режима
    mode_buttons = []
    if show_admin_button:
        mode_buttons.append(KeyboardButton(text="🏢 Режим администратора"))
    if show_master_button:
        mode_buttons.append(KeyboardButton(text="👨‍💼 Режим мастера"))

    if mode_buttons:
        buttons.append(mode_buttons)

    keyboard = ReplyKeyboardMarkup(
        keyboard=buttons,
        resize_keyboard=True
    )
    return keyboard


def get_businesses_keyboard(businesses: List[Business]) -> InlineKeyboardMarkup:
    """Клавиатура для выбора бизнеса"""
    builder = InlineKeyboardBuilder()

    for business in businesses:
        business_type = get_business_type_name(business.business_type)
        builder.button(
            text=f"{business.name} ({business_type})",
            callback_data=f"business:{business.id}"
        )

    builder.button(text="🏠 Главное меню", callback_data="client_main_menu")
    builder.adjust(1)  # По 1 кнопке в ряд
    return builder.as_markup()


def get_services_keyboard(services: List[Service], selected_ids: List[int] = None) -> InlineKeyboardMarkup:
    """Клавиатура для выбора услуг (мультивыбор)"""
    builder = InlineKeyboardBuilder()
    selected_ids = selected_ids or []

    for service in services:
        price_text = f" - {service.price}₽" if service.price else ""
        # Отмечаем выбранные услуги галочкой
        check = "✅ " if service.id in selected_ids else ""
        builder.button(
            text=f"{check}{service.name} ({service.duration_minutes} мин{price_text})",
            callback_data=f"service:{service.id}"
        )

    # Кнопка "Готово" появляется только если выбрана хотя бы одна услуга
    if selected_ids:
        builder.button(text="✔️ Готово - продолжить", callback_data="services_done")

    builder.button(text="◀️ Назад", callback_data="back_to_businesses")
    builder.button(text="🏠 Главное меню", callback_data="client_main_menu")
    builder.adjust(1)
    return builder.as_markup()


def get_employees_keyboard(employees: List[Employee]) -> InlineKeyboardMarkup:
    """Клавиатура для выбора сотрудника"""
    builder = InlineKeyboardBuilder()

    builder.button(text="👤 Любой мастер", callback_data="employee:any")

    for employee in employees:
        spec_text = f" - {employee.specialization}" if employee.specialization else ""
        builder.button(
            text=f"{employee.name}{spec_text}",
            callback_data=f"employee:{employee.id}"
        )

    builder.button(text="◀️ Назад", callback_data="back_to_services")
    builder.button(text="🏠 Главное меню", callback_data="client_main_menu")
    builder.adjust(1)
    return builder.as_markup()


def get_dates_keyboard(available_dates: List[Union[str, dict]]) -> InlineKeyboardMarkup:
    """Клавиатура для выбора даты (до месяца вперёд)

    available_dates: список словарей с ключами:
        - display: текст для отображения (например "15 Пн")
        - value: значение для callback_data (например "15.01.2026")
    Или список строк для обратной совместимости
    """
    builder = InlineKeyboardBuilder()

    for date_info in available_dates:
        if isinstance(date_info, dict):
            builder.button(
                text=date_info['display'],
                callback_data=f"date:{date_info['value']}"
            )
        else:
            # Обратная совместимость со старым форматом
            builder.button(
                text=date_info,
                callback_data=f"date:{date_info}"
            )

    builder.button(text="◀️ Назад", callback_data="back_to_employees")
    builder.adjust(4)  # По 4 даты в ряд для компактности
    return builder.as_markup()


def get_times_keyboard(available_times: List[str]) -> InlineKeyboardMarkup:
    """Клавиатура для выбора времени"""
    builder = InlineKeyboardBuilder()

    for time_str in available_times:
        builder.button(
            text=time_str,
            callback_data=f"time:{time_str}"
        )

    builder.button(text="◀️ Назад", callback_data="back_to_dates")
    builder.adjust(3)  # По 3 времени в ряд
    return builder.as_markup()


def get_phone_request_keyboard() -> ReplyKeyboardMarkup:
    """Клавиатура для запроса номера телефона"""
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📱 Отправить номер телефона", request_contact=True)],
            [KeyboardButton(text="❌ Отмена")],
        ],
        resize_keyboard=True,
        one_time_keyboard=True
    )
    return keyboard


def get_confirmation_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура для подтверждения записи"""
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Подтвердить", callback_data="confirm_booking")
    builder.button(text="◀️ Назад", callback_data="back_to_times")
    builder.button(text="❌ Отменить", callback_data="cancel_booking")
    builder.adjust(1)
    return builder.as_markup()


def get_booking_actions_keyboard(booking_id: int) -> InlineKeyboardMarkup:
    """Клавиатура действий с записью"""
    builder = InlineKeyboardBuilder()
    builder.button(text="❌ Отменить запись", callback_data=f"cancel_booking:{booking_id}")
    builder.adjust(1)
    return builder.as_markup()


def get_business_info_keyboard(business_id: int, has_photos: bool = False, has_directions: bool = False) -> InlineKeyboardMarkup:
    """Клавиатура для просмотра информации о бизнесе"""
    builder = InlineKeyboardBuilder()

    if has_photos:
        builder.button(text="📷 Фото заведения", callback_data=f"view_photos:{business_id}")
    if has_directions:
        builder.button(text="🗺 Как добраться", callback_data=f"view_directions:{business_id}")

    builder.adjust(2)
    return builder.as_markup()
