"""
Клавиатуры для админ-панели
"""
from typing import List
from aiogram.types import InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database.models import Business


def get_admin_menu_keyboard(show_master_button: bool = False, is_super_admin: bool = False) -> ReplyKeyboardMarkup:
    """Главное меню для администратора"""
    buttons = [
        [KeyboardButton(text="🏢 Мои бизнесы")],
        [KeyboardButton(text="➕ Добавить бизнес"), KeyboardButton(text="📊 Записи")],
        [KeyboardButton(text="ℹ️ Помощь")],
    ]

    # Добавляем кнопку управления администраторами для супер-админа
    if is_super_admin:
        buttons.append([KeyboardButton(text="👥 Управление администраторами")])

    # Добавляем кнопки переключения режима
    mode_buttons = [KeyboardButton(text="👤 Режим клиента")]
    if show_master_button:
        mode_buttons.append(KeyboardButton(text="👨‍💼 Режим мастера"))
    buttons.append(mode_buttons)

    keyboard = ReplyKeyboardMarkup(
        keyboard=buttons,
        resize_keyboard=True
    )
    return keyboard


def get_businesses_admin_keyboard(businesses: List[Business], callback_prefix: str = "admin_business") -> InlineKeyboardMarkup:
    """Клавиатура для управления бизнесами"""
    builder = InlineKeyboardBuilder()

    for business in businesses:
        status = "✅" if business.is_active else "⏸"
        builder.button(
            text=f"{status} {business.name}",
            callback_data=f"{callback_prefix}:{business.id}"
        )

    builder.button(text="➕ Создать бизнес", callback_data="create_business")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")
    builder.adjust(1)
    return builder.as_markup()


def get_business_management_keyboard(business_id: int) -> InlineKeyboardMarkup:
    """Клавиатура управления конкретным бизнесом"""
    builder = InlineKeyboardBuilder()

    builder.button(text="✏️ Редактировать", callback_data=f"edit_business:{business_id}")
    builder.button(text="📋 Услуги", callback_data=f"manage_services:{business_id}")
    builder.button(text="👥 Сотрудники", callback_data=f"manage_employees:{business_id}")
    builder.button(text="🗑 Удалить бизнес", callback_data=f"delete_business:{business_id}")
    builder.button(text="◀️ Назад", callback_data="admin_back_to_list")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")

    builder.adjust(1)
    return builder.as_markup()


def get_business_edit_keyboard(business_id: int) -> InlineKeyboardMarkup:
    """Клавиатура выбора поля для редактирования"""
    builder = InlineKeyboardBuilder()

    builder.button(text="📝 Название", callback_data=f"edit_field:name:{business_id}")
    builder.button(text="📄 Описание", callback_data=f"edit_field:description:{business_id}")
    builder.button(text="📍 Адрес", callback_data=f"edit_field:address:{business_id}")
    builder.button(text="📞 Телефон", callback_data=f"edit_field:phone:{business_id}")
    builder.button(text="⏰ Время работы", callback_data=f"edit_field:hours:{business_id}")
    builder.button(text="☕ Перерыв", callback_data=f"edit_field:break:{business_id}")
    builder.button(text="📷 Фотографии", callback_data=f"edit_field:photos:{business_id}")
    builder.button(text="🗺 Как добраться", callback_data=f"edit_field:directions:{business_id}")
    builder.button(text="◀️ Назад", callback_data=f"admin_business:{business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")

    builder.adjust(1)
    return builder.as_markup()


def get_business_types_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура для выбора типа бизнеса"""
    builder = InlineKeyboardBuilder()

    types = [
        ("💇 Салон красоты", "salon"),
        ("🧠 Психолог", "psychologist"),
        ("🚗 Автосервис", "auto_service"),
        ("🔧 Шиномонтаж", "tire_service"),
        ("💆 Массаж/СПА", "spa"),
        ("🏥 Медицинская клиника", "medical"),
        ("🎓 Обучение", "education"),
        ("✂️ Другое", "other"),
    ]

    for text, callback in types:
        builder.button(text=text, callback_data=f"business_type:{callback}")

    builder.adjust(2)
    return builder.as_markup()


def get_bookings_filter_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура фильтров для просмотра записей"""
    builder = InlineKeyboardBuilder()

    builder.button(text="📅 Сегодня", callback_data="filter:today")
    builder.button(text="📅 Завтра", callback_data="filter:tomorrow")
    builder.button(text="📅 Неделя", callback_data="filter:week")
    builder.button(text="📅 Все", callback_data="filter:all")

    builder.adjust(2)
    return builder.as_markup()


def get_booking_admin_actions_keyboard(booking_id: int) -> InlineKeyboardMarkup:
    """Клавиатура действий администратора с записью"""
    builder = InlineKeyboardBuilder()

    builder.button(text="✅ Подтвердить", callback_data=f"admin_confirm:{booking_id}")
    builder.button(text="✔️ Завершить", callback_data=f"admin_complete:{booking_id}")
    builder.button(text="❌ Отменить", callback_data=f"admin_cancel:{booking_id}")

    builder.adjust(1)
    return builder.as_markup()


def get_photos_management_keyboard(business_id: int, has_photos: bool) -> InlineKeyboardMarkup:
    """Клавиатура управления фотографиями бизнеса"""
    builder = InlineKeyboardBuilder()

    builder.button(text="➕ Добавить фото", callback_data=f"add_photo:{business_id}")
    if has_photos:
        builder.button(text="🗑 Удалить все фото", callback_data=f"delete_all_photos:{business_id}")
    builder.button(text="◀️ Назад к редактированию", callback_data=f"back_to_edit:{business_id}")
    builder.button(text="🏠 Главное меню", callback_data="main_menu")

    builder.adjust(1)
    return builder.as_markup()


def get_admin_management_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура управления администраторами"""
    builder = InlineKeyboardBuilder()

    builder.button(text="➕ Добавить администратора", callback_data="add_admin")
    builder.button(text="🗑 Удалить администратора", callback_data="remove_admin")
    builder.button(text="◀️ Назад", callback_data="back_to_admin_menu")

    builder.adjust(1)
    return builder.as_markup()


def get_admin_list_keyboard(admin_info: dict) -> InlineKeyboardMarkup:
    """Клавиатура со списком администраторов для удаления

    Args:
        admin_info: словарь {admin_id: display_name}
    """
    builder = InlineKeyboardBuilder()

    for admin_id, display_name in admin_info.items():
        builder.button(text=f"🗑 {display_name}", callback_data=f"delete_admin:{admin_id}")

    builder.button(text="◀️ Назад", callback_data="manage_admins")
    builder.adjust(1)
    return builder.as_markup()
