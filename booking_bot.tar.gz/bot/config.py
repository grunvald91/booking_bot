"""
Конфигурация бота
Загружает настройки из .env файла
"""
import os
from dotenv import load_dotenv

load_dotenv()

# Telegram Bot
BOT_TOKEN = os.getenv("BOT_TOKEN")
if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN не найден в .env файле!")

# Database
DB_TYPE = os.getenv("DB_TYPE", "sqlite")  # sqlite или postgresql

if DB_TYPE == "sqlite":
    # Используем SQLite (не требует установки, для тестирования)
    DATABASE_URL = "sqlite+aiosqlite:///booking_bot.db"
else:
    # Используем PostgreSQL (для production)
    DB_HOST = os.getenv("DB_HOST", "localhost")
    DB_PORT = os.getenv("DB_PORT", "5432")
    DB_NAME = os.getenv("DB_NAME", "booking_bot")
    DB_USER = os.getenv("DB_USER", "postgres")
    DB_PASSWORD = os.getenv("DB_PASSWORD")
    DATABASE_URL = f"postgresql+asyncpg://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# Timezone
TIMEZONE = os.getenv("TIMEZONE", "Europe/Moscow")

# Администраторы
ADMIN_IDS = [int(id_) for id_ in os.getenv("ADMIN_IDS", "").split(",") if id_.strip()]
