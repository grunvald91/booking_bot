"""
FSM состояния для админ-панели
"""
from aiogram.fsm.state import State, StatesGroup


class BusinessCreationStates(StatesGroup):
    """Состояния для создания бизнеса"""
    entering_name = State()
    entering_type = State()
    entering_description = State()
    entering_address = State()
    entering_phone = State()
    entering_working_hours = State()
    entering_break_time = State()
    entering_booking_interval = State()


class ServiceCreationStates(StatesGroup):
    """Состояния для создания услуги"""
    choosing_business = State()
    entering_name = State()
    entering_description = State()
    entering_duration = State()
    entering_price = State()


class EmployeeCreationStates(StatesGroup):
    """Состояния для создания сотрудника"""
    choosing_business = State()
    entering_name = State()
    entering_specialization = State()
    entering_telegram_id = State()
    entering_booking_interval = State()


class BusinessEditStates(StatesGroup):
    """Состояния для редактирования бизнеса"""
    choosing_field = State()
    editing_name = State()
    editing_description = State()
    editing_address = State()
    editing_phone = State()
    editing_working_hours = State()
    editing_break = State()
    editing_photos = State()
    editing_directions = State()


class ServiceEditStates(StatesGroup):
    """Состояния для редактирования услуги"""
    editing_name = State()
    editing_description = State()
    editing_duration = State()
    editing_price = State()


class EmployeeEditStates(StatesGroup):
    """Состояния для редактирования сотрудника"""
    editing_name = State()
    editing_specialization = State()
    editing_telegram_id = State()
    editing_interval = State()
