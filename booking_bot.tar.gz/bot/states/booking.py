"""
FSM состояния для процесса записи клиента
"""
from aiogram.fsm.state import State, StatesGroup


class BookingStates(StatesGroup):
    """Состояния для процесса записи на услугу"""
    choosing_business = State()      # Выбор бизнеса
    choosing_service = State()       # Выбор услуги
    choosing_employee = State()      # Выбор мастера/специалиста
    choosing_date = State()          # Выбор даты
    choosing_time = State()          # Выбор времени
    entering_phone = State()         # Ввод номера телефона
    confirming = State()             # Подтверждение записи
