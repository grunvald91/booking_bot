"""
Модуль для отправки уведомлений клиентам, мастерам и владельцам
"""
import logging
from datetime import datetime, timedelta
from typing import Optional

from aiogram import Bot
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from database import async_session_maker
from database.models import Booking, User, Business, Employee

logger = logging.getLogger(__name__)


async def send_24h_reminder(bot: Bot, booking: Booking, session: AsyncSession):
    """Отправка напоминания клиенту за 24 часа до записи"""
    try:
        client = booking.client
        business = booking.business
        service = booking.service
        employee = booking.employee

        booking_datetime = datetime.combine(booking.booking_date, booking.booking_time)

        message = f"""
🔔 <b>Напоминание о записи</b>

📅 Дата: {booking.booking_date.strftime('%d.%m.%Y')}
🕐 Время: {booking.booking_time.strftime('%H:%M')}

🏢 {business.name}
💼 Услуга: {service.name}
⏱ Длительность: {service.duration_minutes} мин
💰 Цена: {service.price} ₽
"""

        if employee:
            message += f"👔 Мастер: {employee.name}\n"

        if business.address:
            message += f"\n📍 Адрес: {business.address}"

        if business.directions:
            message += f"\n\n🗺 Как добраться:\n{business.directions}"

        message += "\n\nДо встречи! 👋"

        await bot.send_message(
            chat_id=client.telegram_id,
            text=message,
            parse_mode="HTML"
        )

        # Отмечаем что уведомление отправлено
        booking.reminder_24h_sent = True
        await session.commit()

        logger.info(f"Sent 24h reminder for booking {booking.id} to user {client.telegram_id}")

    except Exception as e:
        logger.error(f"Error sending 24h reminder for booking {booking.id}: {e}")


async def send_2h_reminder(bot: Bot, booking: Booking, session: AsyncSession):
    """Отправка напоминания клиенту за 2 часа до записи"""
    try:
        client = booking.client
        business = booking.business
        service = booking.service
        employee = booking.employee

        booking_datetime = datetime.combine(booking.booking_date, booking.booking_time)

        # Если уведомление за 24ч не было отправлено (запись создана недавно),
        # отправляем полное уведомление
        if not booking.reminder_24h_sent:
            message = f"""
🔔 <b>Напоминание о записи через 2 часа!</b>

📅 Дата: {booking.booking_date.strftime('%d.%m.%Y')}
🕐 Время: {booking.booking_time.strftime('%H:%M')}

🏢 {business.name}
💼 Услуга: {service.name}
⏱ Длительность: {service.duration_minutes} мин
💰 Цена: {service.price} ₽
"""

            if employee:
                message += f"👔 Мастер: {employee.name}\n"

            if business.address:
                message += f"\n📍 Адрес: {business.address}"

            if business.directions:
                message += f"\n\n🗺 Как добраться:\n{business.directions}"

            message += "\n\nДо встречи через 2 часа! 👋"
        else:
            # Краткое напоминание, если уже отправляли за 24ч
            message = f"""
⏰ <b>Напоминание: через 2 часа ваша запись!</b>

🕐 Время: {booking.booking_time.strftime('%H:%M')}
🏢 {business.name}
💼 {service.name}
"""

            if business.address:
                message += f"\n📍 Адрес: {business.address}"

            message += "\n\nЖдём вас! 😊"

        await bot.send_message(
            chat_id=client.telegram_id,
            text=message,
            parse_mode="HTML"
        )

        # Отмечаем что уведомление отправлено
        booking.reminder_2h_sent = True
        await session.commit()

        logger.info(f"Sent 2h reminder for booking {booking.id} to user {client.telegram_id}")

    except Exception as e:
        logger.error(f"Error sending 2h reminder for booking {booking.id}: {e}")


async def notify_master_new_booking(bot: Bot, booking: Booking):
    """Уведомление мастеру о новой записи"""
    try:
        if not booking.employee or not booking.employee.telegram_id:
            return

        employee = booking.employee
        client = booking.client
        service = booking.service

        message = f"""
🆕 <b>Новая запись!</b>

📅 Дата: {booking.booking_date.strftime('%d.%m.%Y')}
🕐 Время: {booking.booking_time.strftime('%H:%M')}

👤 Клиент: {client.full_name}
"""

        if client.phone:
            message += f"📱 Телефон: {client.phone}\n"

        message += f"""
💼 Услуга: {service.name}
⏱ Длительность: {service.duration_minutes} мин
"""

        if booking.notes:
            message += f"\n💬 Комментарий: {booking.notes}"

        await bot.send_message(
            chat_id=employee.telegram_id,
            text=message,
            parse_mode="HTML"
        )

        logger.info(f"Notified master {employee.telegram_id} about booking {booking.id}")

    except Exception as e:
        logger.error(f"Error notifying master about booking {booking.id}: {e}")


async def notify_owner_new_booking(bot: Bot, booking: Booking):
    """Уведомление владельцу о новой записи"""
    try:
        # Все данные уже подгружены в booking через selectinload
        business = booking.business
        owner = business.owner
        client = booking.client
        service = booking.service
        employee = booking.employee

        message = f"""
🆕 <b>Новая запись в {business.name}</b>

📅 {booking.booking_date.strftime('%d.%m.%Y')} в {booking.booking_time.strftime('%H:%M')}

👤 Клиент: {client.full_name}
💼 Услуга: {service.name}
"""

        if employee:
            message += f"👔 Мастер: {employee.name}\n"

        message += f"💰 Сумма: {service.price} ₽"

        await bot.send_message(
            chat_id=owner.telegram_id,
            text=message,
            parse_mode="HTML"
        )

        logger.info(f"Notified owner {owner.telegram_id} about booking {booking.id}")

    except Exception as e:
        logger.error(f"Error notifying owner about booking {booking.id}: {e}")


async def notify_owner_cancelled_booking(bot: Bot, booking: Booking):
    """Уведомление владельцу об отмене записи"""
    try:
        # Все данные уже подгружены в booking через selectinload
        business = booking.business
        owner = business.owner
        client = booking.client
        service = booking.service

        message = f"""
❌ <b>Отменена запись в {business.name}</b>

📅 {booking.booking_date.strftime('%d.%m.%Y')} в {booking.booking_time.strftime('%H:%M')}

👤 Клиент: {client.full_name}
💼 Услуга: {service.name}
💰 Потеря: {service.price} ₽
"""

        await bot.send_message(
            chat_id=owner.telegram_id,
            text=message,
            parse_mode="HTML"
        )

        logger.info(f"Notified owner {owner.telegram_id} about cancelled booking {booking.id}")

    except Exception as e:
        logger.error(f"Error notifying owner about cancelled booking {booking.id}: {e}")


async def check_and_send_reminders(bot: Bot):
    """Проверка и отправка напоминаний о предстоящих записях"""
    try:
        async with async_session_maker() as session:
            now = datetime.utcnow()  # Используем UTC как в моделях

            # Проверяем записи для напоминания за 24 часа
            time_24h_from_now = now + timedelta(hours=24)
            time_24h_window_start = time_24h_from_now - timedelta(minutes=5)
            time_24h_window_end = time_24h_from_now + timedelta(minutes=5)

            result = await session.execute(
                select(Booking)
                .where(Booking.status.in_(["pending", "confirmed"]))
                .where(Booking.reminder_24h_sent == False)
            )
            bookings_24h = result.scalars().all()

            for booking in bookings_24h:
                booking_datetime = datetime.combine(booking.booking_date, booking.booking_time)

                if time_24h_window_start <= booking_datetime <= time_24h_window_end:
                    await send_24h_reminder(bot, booking, session)

            # Проверяем записи для напоминания за 2 часа
            time_2h_from_now = now + timedelta(hours=2)
            time_2h_window_start = time_2h_from_now - timedelta(minutes=5)
            time_2h_window_end = time_2h_from_now + timedelta(minutes=5)

            result = await session.execute(
                select(Booking)
                .where(Booking.status.in_(["pending", "confirmed"]))
                .where(Booking.reminder_2h_sent == False)
            )
            bookings_2h = result.scalars().all()

            for booking in bookings_2h:
                booking_datetime = datetime.combine(booking.booking_date, booking.booking_time)

                if time_2h_window_start <= booking_datetime <= time_2h_window_end:
                    await send_2h_reminder(bot, booking, session)

            logger.info(f"Checked reminders: {len(bookings_24h)} for 24h, {len(bookings_2h)} for 2h")

    except Exception as e:
        logger.error(f"Error checking reminders: {e}")


async def auto_complete_bookings():
    """Автоматическое завершение записей после окончания времени услуги"""
    try:
        async with async_session_maker() as session:
            now = datetime.utcnow()  # Используем UTC как в моделях

            # Находим все подтвержденные записи, которые должны быть завершены
            result = await session.execute(
                select(Booking)
                .options(selectinload(Booking.service))
                .where(Booking.status.in_(["pending", "confirmed"]))
            )
            active_bookings = result.scalars().all()

            completed_count = 0
            for booking in active_bookings:
                # Вычисляем время окончания услуги
                booking_datetime = datetime.combine(booking.booking_date, booking.booking_time)
                service_end_time = booking_datetime + timedelta(minutes=booking.service.duration_minutes)

                # Если время услуги прошло, завершаем запись
                if now >= service_end_time:
                    booking.status = "completed"
                    completed_count += 1

            if completed_count > 0:
                await session.commit()
                logger.info(f"Auto-completed {completed_count} bookings")

    except Exception as e:
        logger.error(f"Error auto-completing bookings: {e}")
